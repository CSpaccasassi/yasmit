module JDisassembler where

import Char 
--import System.IO
--import System.Console.GetOpt
import Text.ParserCombinators.Parsec
import Text.ParserCombinators.Parsec.Token
import Text.ParserCombinators.Parsec.Prim (try)
import Text.ParserCombinators.Parsec.Error
import Array
--import System
import JClassData
import JClassPrinter
import JOpcodes
import JParser
import Data.Bits
import Data.Word
import Text.ParserCombinators.Parsec

_VERSIONNUMBER = 1.0
_JAVA_LANG_OBJECT = "java/lang/Object"
_MAX_CONSTANT_POOL_ENTRIES = 65535 -- 65535 = 2^16 - 1 = span(u2)

--XXX: IMPORTANTE: CAMBIA IL CONSTANT POOL!!!!!
--XXX: AGGIUNGI IL CONTROLLO DELLA VERSIONE '< 50'
--XXX: utility: mask extract
-- ExtractFlags extracts from a mask the flags indicated in the
-- flagMap and collects them in a list. The flagMap is a list
-- of couples of the following format: 
-- (flag hexcode, flag )
maskToFlags :: (Bits a, Eq a1) => a -> [(a, a1)] -> [a1]
maskToFlags mask flagMap = foldl (\c (a, b)-> if ((mask .&. a) == a) then (b:c) else c ) [] flagMap

---XXX: utility: for loop
-- executes the given task n times
repeatN task n= map (\_ -> task) [1..n]

entryAtIndex i cp 
	| i <= 0 		= error $ "Invalid constant pool index " ++ show i
	| otherwise	= cp ! i



--XXX: utility: Translate an integer to its hexadecimal representation in a string.
--							It is used while modifying the original .class file.
u1Hex :: Int -> String
u1Hex i
	| i > 0 && i <= 0xFF    = [chr i]
	| otherwise             = error ("u1Hex: out of bound number: " ++ show i)

u2Hex :: Int -> String
u2Hex i
	| i > 0 && i <= 0xFF    = (chr 0):(chr i):[]
	| i > 0 && i <= 0xFFFF  = (chr $ shiftR (i .&. 0xFF00) 8):(chr $ i .&. 0xFF):[]
	| otherwise   = error ("u2Hex: out of bound number: " ++ show i)
	
u4Hex :: Int -> String
u4Hex i
	| i > 0 && i <= 0xFFFF      = (chr 0):[(chr 0)] ++ (u2Hex i)
	| i > 0 && i <= 0xFFFFFF    = (chr 0):(chr $ shiftR (i .&. 0x00FF0000) 16):[] ++ (u2Hex (i .&. 0xFFFF))
	| i > 0 && i <= 0x7FFFFFFF  = (u2Hex $ shiftR (i .&. 0xFFFF0000) 16) ++ (u2Hex (i .&. 0xFFFF))
	| i < 0 && i >= 0xFFFFFFFF  = (u2Hex $ (0 - (i .&. 0xFFFF0000)) - 1) ++ (u2Hex (i .&. 0xFFFF))
	| otherwise                 = error ("u4Hex: out of bound number: " ++ show i)



-- XXX: error messages
c_classError i = "expecting constant_Class entry in the constant pool at index " ++ show i
c_mutf8Error i = "expecting constant_MUTF8 entry in the constant pool at index " ++ show i

{-------------------------
 - -----------------------
 - METADATA DISASSEMBLER
 - -----------------------
 -------------------------}

magicNumber :: JParser ()
magicNumber = do
	u1check 0xCA
	u1check 0xFE
	u1check 0xBA
	u1check 0xBE
	return ()
	<?> "not a java class file"

classVersion :: JParser ClassVersion
classVersion = do
	minorNumber <- u2
	majorNumber <- u2
	return $ CV (majorNumber, minorNumber)
	

{------------------------------
 - ----------------------------
 - CONSTANT POOL DISASSEMBLER
 - ----------------------------
 ------------------------------}

-- Constant Pool Tag Parser
-- XXX: METTI IL TRY!!!!!!!!!!
cpTag = u1check

-- Constant Pool Entry Tags
utf8tag 								=	1
classTag 								=	7
fieldRefTag 						=	9
methodRefTag 						=	10
interfaceMethodRefTag 	=	11
stringTag								=	8
integerTag							=	3
floatTag								=	4
longTag									=	5
doubleTag								=	6
nameAndTypeTag					=	12
------
-- Modified Utf8 Characters Parser
------
oneByteModUtf8 		i 			= i
twoByteModUtf8 		i j 		= ((i .&. 0x1f) << 6) + (j .&. 0x3f)
threeByteModUtf8 	i j k		= ((i .&. 0xf) << 12) + ((j .&. 0x3f) << 6) + (k .&. 0x3f)
sixByteModUtf8		i	j	k	l	= (0x10000 + ((i .&. 0x0f) <<16) + ((j .&. 0x3f) << 10) + (k .&. 0x0f) <<6) + (l .&. 0x3f)

modified_Utf8 :: Int -> JParser [Int]
modified_Utf8 i | i == 0 = return []
								| i > 0 = do
	firstByte <- u1
	if not (testBit firstByte 7) 
		then 				do
									tail 				<- 	modified_Utf8 (i-1)
									return $	(oneByteModUtf8 firstByte) : tail
		else if not (testBit firstByte 6) 
			then 				
									fail "unrecognized modified-Utf8 character"
			else if not (testBit firstByte 5) 
				then 		do	
									secondByte	<-	u1
									tail 				<- 	modified_Utf8 (i-2)
									return $  (twoByteModUtf8 firstByte secondByte) : tail 
				else if not (firstByte == 237) 	-- 237 = 1110 1101 = 6-byte char marker (see below)
					then	do	
									secondByte	<-	u1
									thirdByte		<-	u1
									tail 				<-	modified_Utf8 (i-3)
									return $  (threeByteModUtf8 firstByte secondByte thirdByte) : tail
					else 	do	
									secondByte	<-	u1
									thirdByte		<-	u1
									u1check 237								--modified-Utf8 marker (see section 4.5.7 in JVML Specification)
									fifthByte		<-	u1
									sixthByte		<-	u1
									tail				<-	(modified_Utf8 (i-6))
									return $  (sixByteModUtf8 secondByte thirdByte fifthByte sixthByte) : tail 
	<?> "unrecognized modified-Utf8 character"
								| i < 0 = fail "invalid Utf8 string length"

-------
-- XXX: reference check: array valid iff <=255 dimensions
constant_Utf8 :: JParser CPEntry
constant_Utf8 = do
	cpTag utf8tag	-- 1
	utf8_length <- u2
	utf8_string <- modified_Utf8 utf8_length
	return $ MUtf8 (map chr utf8_string)

-------
-- XXX: reference check : index must be a valid interface or class identifier
constant_Class = do
	cpTag classTag	-- 7
	classIndex <- u2
	return  $ C classIndex

-------
--XXX: reference check: index può essere sia interface che class
--XXX: reference check: nameAndTypeIndex deve essere FieldRef
constant_FieldRef = do
	cpTag fieldRefTag -- 9
	classIndex 				<- u2
	nameAndTypeIndex 	<- u2
	return $ FR	classIndex nameAndTypeIndex

-------
--XXX: reference check: index deve essere class
--XXX: reference check: nameAndTypeIndex deve essere MethodRef
--XXX: reference check: se il nome comincia per '<', deve essere '<init>' con return type void
constant_MethodRef = do
	cpTag methodRefTag	-- 10
	classIndex 				<- u2
	nameAndTypeIndex 	<- u2
	return $ MR classIndex nameAndTypeIndex

-------
--XXX: reference check: index deve essere interface
--XXX: reference check: nameAndTypeIndex deve essere MethodRef
constant_InterfaceMethodRef = do
	cpTag interfaceMethodRefTag	-- 11
	classIndex 				<- u2
	nameAndTypeIndex 	<- u2
	return $ IMR classIndex nameAndTypeIndex

-------
--XXX: reference check: utf8
constant_String = do
	cpTag stringTag	-- 8
	stringIndex <- u2
	return $ S stringIndex

-------
constant_Integer = do
	cpTag integerTag -- 3
	i <- u4
	return $ I (fromIntegral i)

-------
intToJFloat :: Integer -> Float
intToJFloat i | (i == 0x7f800000)		= 1 / 0
							|	(i == 0xff800000)		= 0 - (1/ 0)
							|	(0x7f800001 < i && i < 0x7fffffff) ||	
								(0xff800001 < i && i < 0xffffffff) 		= 0 / 0
							|	otherwise						=	s * m * (2 ^^ (e - 150))
																				where 
																					s = if ((testBit i 31)) then -1 else 1
																					e = (shiftR i 23) .&. 0xff
																					m = fromIntegral $ if (e == 0) then (i .&. 0x7fffff) << 1
																																				 else (i .&. 0x7fffff) .|. 0x800000

constant_Float = do
	cpTag floatTag -- 4
	i	<- u4
	return $ F $ intToJFloat (fromIntegral i)

-------
constant_Long = do
	cpTag longTag	-- 5
	upper <- u4
	lower <- u4
	{-signedUpper <- u4
	signedLower <- u4
	let upper = unsign_u4 signedUpper
	let lower = unsign_u4 signedLower-}
	--return $ L $ fromIntegral ((upper << 32) + lower)
	return $ L $ fromIntegral ((upper * 2^32) + lower)

-------
intToJDouble :: Integer -> Double
intToJDouble i 	| (i == 0x7ff0000000000000)		= 1/0
								|	(i == 0xfff0000000000000)		=	0 - (1/0)
								| (0x7ff0000000000001 < i && i < 0x7fffffffffffffff) || 
									(0xfff0000000000001 < i && i < 0xffffffffffffffff) 		= 0 / 0
								| otherwise	= s *  m * (2 ^^ (e - 1075))
																where
																	s = if (testBit i 63) then -1 else 1
																	e = (shiftR i 52) .&. 0x7ff
																	m = fromIntegral $ if (e == 0) then ((i .&. 0xfffffffffffff) << 1)
																															 	 else ((i .&. 0xfffffffffffff) .|. 0x10000000000000)
															



constant_Double = do
	cpTag	doubleTag -- 6
	upper <- u4
	lower <- u4
	return $ D $ intToJDouble $ ((fromIntegral upper) << 32) + (fromIntegral lower) 

-------
--XXX: reference check: name: Utf8 with either <init> or a valid method or field name
--XXX: reference check: type: Utf8 with a valid field or method descriptor
constant_NameAndType = do
	cpTag nameAndTypeTag -- 12
	i1	<- 	u2
	i2	<-	u2
	return $ NT i1 i2

-------

constantPoolEntry :: JParser CPEntry
constantPoolEntry = 
			constant_Utf8
	<|>	constant_Class
	<|>	constant_FieldRef
	<|>	constant_MethodRef
	<|>	constant_InterfaceMethodRef
	<|>	constant_String
	<|>	constant_Integer
	<|>	constant_Float
	<|>	constant_Long
	<|>	constant_Double
	<|>	constant_NameAndType


-- Parses a constant pool entry and associates the given number to the entry
constantPoolEntries :: Int -> Int -> JParser [(Int, CPEntry)]
constantPoolEntries i max 
	| i == max				= return []{-if (max < _MAX_CONSTANT_POOL_ENTRIES) 
												then
													do
														let stackMapEntry = (u1Hex 1) ++ (u2Hex 13) ++ ("StackMapTable")
														updateState (++ stackMapEntry)
														return [(max, MUtf8 "StackMapTable")]
												else fail "Cannot create a StackMap entry: the constant pool is full."-}
	| otherwise				= do
										e	<- constantPoolEntry
										case e of
											L _		->	do
														tail <- constantPoolEntries (i+2) max
														return $ (i, e):(i+1, Unusable):tail
											D	_		->	do
														tail <- constantPoolEntries (i+2) max
														return $ (i, e):(i+1, Unusable):tail
											_			->	do
														tail <- constantPoolEntries (i+1) max
														return $ (i, e):tail

-- Disassemble the constant pool
disassembleConstantPool :: JParser (Array Int CPEntry)
disassembleConstantPool = do
	cpCount	<- u2
	entries <- constantPoolEntries 1 (cpCount) -- minus one since cpCount = max_constants + 1
	return $ array (1, cpCount - 1) entries

-- Disassemble the constant pool and add the Constant_MUtf8 "StackMapTable" entry
disassembleAndModifyConstantPool :: JParser (Array Int CPEntry)
disassembleAndModifyConstantPool = do
	originalState <- getState
	cpCount				<- u2
	if cpCount < _MAX_CONSTANT_POOL_ENTRIES
		then do
			-- increase the count size of constant pool entries in the state
			updateState (\_ -> originalState ++ (u2Hex $cpCount + 1))
			
			-- parse cp entries
			entries 		<- constantPoolEntries 1 (cpCount)
			
			-- add Constant_MUtf8 StackMapTable in the constant pool
			let stackMapHex = (u1Hex 1) ++ (u2Hex 13) ++ ("StackMapTable")
			updateState (++ stackMapHex)
			
			-- return the modified constant pool
			let stackMapEntry = (cpCount, MUtf8 "StackMapTable")
			return $ array (1, cpCount) (entries ++ [stackMapEntry])
		
		else fail "Cannot create a StackMap entry: the constant pool is full."



{----------------------
 - --------------------
 - FIELD DISASSEMBLER
 - --------------------
 ----------------------}
fieldAccessFlags :: [(Int, FieldAccessFlag)]
fieldAccessFlags = [	(0x0001, PublicF),
											(0x0002, PrivateF),
											(0x0004, ProtectedF),
											(0x0008, StaticF),
											(0x0010, FinalF),
											(0x0040, VolatileF),
											(0x0080, TransientF),
											(0x1000, SyntheticF),
											(0x4000, EnumF)				]	

------

constantFieldAttribute = do 
	length <- u4
	if (length /= 2) 	
		then 	fail $ "found constant attribute's length " ++ show length ++ ", expecting 2"
		else 	do
				valueIndex <- u2
				return $ CFV valueIndex

syntheticFieldAttribute = do
	length <- u4
	if (length /= 0) 	then fail $ "found synthetic attribute's length " ++ show length ++ ", expecting 0"
										else return SyntheticFA

deprecatedFieldAttribute = do
	length <- u4
	if (length /= 0) 	then fail $ "found deprecated attribute's length " ++ show length ++ ", expecting 0"
										else return DeprecatedFA

----
--
----
-- Parse a base type (or "field type" in Java Virtual Machine Specification's terminology)
{-fieldType :: Parser FieldType
fieldType = do { char 'B' ; spaces ; return Jbyte   }
				<|> do { char 'C' ; spaces ; return Jchar   }
				<|> do { char 'D' ; spaces ; return Jdouble }
				<|> do { char 'F' ; spaces ; return Jfloat  }
				<|> do { char 'I' ; spaces ; return Jint    }
				<|> do { char 'J' ; spaces ; return Jlong   }
				<|> do { char 'S' ; spaces ; return Jshort  }
				<|> do { char 'Z' ; spaces ; return Jbool   }
				<|> do { char '[' ; t <- fieldType ; spaces ; return $ Jarray t }
				<|> do { char 'L' ; c <- manyTill anyChar (char ';') ; spaces ; return $ Jclass c }-}

fieldSignature (x:[]) 	= case x of
													'B'	-> Jbyte
													'C'	-> Jchar
													'D'	-> Jdouble
													'F'	-> Jfloat
													'I'	-> Jint
													'J'	-> Jlong
													'S'	-> Jshort
													'Z'	-> Jbool

fieldSignature (x:t)		= case x of
													'L'	-> Jclass (take ((length t) - 1 ) t) -- remove the trailing ';'
													'['	-> Jarray $ fieldSignature t

fieldSignatureAttribute :: ConstantPool -> JParser FieldAttribute
fieldSignatureAttribute cp = do
	length <- u4
	if (length /= 2) 	then fail $ "found signature attribute's length " ++ show length ++ ", expecting 2"
										else do
												 sigIndex <- u2
												 case (entryAtIndex sigIndex cp) of
														MUtf8 sig	->	return $ FS (fieldSignature sig)
														_					->	fail $ c_mutf8Error sigIndex

skipFieldAttribute	s =	do
	length <- u4
	mapM (\_ -> u1) [1..length]
	return $ UnknownFA s

fieldAttribute cp = do
	nameIndex <- u2
	case (entryAtIndex nameIndex cp) of
		MUtf8 "ConstantValue"	->	constantFieldAttribute
		MUtf8	"Synthetic"			->	syntheticFieldAttribute
		MUtf8	"Signature"			->	fieldSignatureAttribute cp
		MUtf8	"Deprecated"		->	deprecatedFieldAttribute
		MUtf8	s								->	skipFieldAttribute s


-------

disassembleField cp = do
	accessFlagsMask <- u2
	nameIndex				<- u2
	descriptorIndex	<- u2
	attributesCount	<- u2	
	let accessFlags = maskToFlags accessFlagsMask fieldAccessFlags
	return $ JF  (show nameIndex, Jbyte, accessFlags, []) --REMOVE
	attributes  <- sequence $  repeatN (fieldAttribute cp) attributesCount
	if (nameIndex == 0 || descriptorIndex == 0) then fail "debug: nameIndex or descriptorIndex is zero"
		else 	case (entryAtIndex nameIndex cp) of
		MUtf8 name	->	case (entryAtIndex descriptorIndex cp) of
												MUtf8	fType		->	return $ JF (name, fieldSignature fType, accessFlags, attributes)
												_							->	fail $ "expecting constant_UTF8 (descripter) at index "	++ show descriptorIndex
		_						->	fail $ "expecting constant_UTF8 (name) at index " ++ show nameIndex
	

{-------------------
 - ----------------
 - METADATA PARSER
 - ----------------
 -------------------}
--XXX: access flag check: interface -> abstract & NOT (super, final, enum)
--XXX: access flag check: annotation -> interface
--XXX: access flag check: not interface: any other flag may be present, except annotation
--XXX: access flag check: NOT ABSTRACT && FINAL together
classAccessFlags = [	(0x0001, PublicC),
											(0x0010, FinalC),
											(0x0020, SuperC),
											(0x0200, InterfaceC),
											(0x0400, AbstractC),
											(0x1000, SyntheticC),
											(0x2000, AnnotationC),
											(0x4000, EnumC) 			]

-------

disassembleMetadata cp = do
	accessMask			<- u2
	let flags = maskToFlags accessMask classAccessFlags
	thisClassIndex	<- u2	--XXX: reference check: reference must be a constant_Class in cp
	superClassIndex	<- u2	--XXX: reference check: reference must be a constant_Class in cp
	-- XXX: IMPORTANT: parse interfaces names too!
	interfacesCount	<- u2	
	interfaces  		<- if (interfacesCount == 0) 
											then return []
											else mapM (\_ -> do {n <- u2; return n}) [1..interfacesCount]
	case (entryAtIndex thisClassIndex cp) of
		C i	->	case (entryAtIndex i cp) of
							MUtf8	this	-> if (superClassIndex == 0)
															then return (CN this, CA flags, Nothing, CI interfaces)
															else
																case (entryAtIndex superClassIndex cp) of
																	C j	-> case (entryAtIndex j cp) of
																						MUtf8	super	->	return (CN this, CA flags, Just $ CP super, CI interfaces)
																						_						->	fail $ c_mutf8Error j
																	_		->	fail $	c_classError superClassIndex
							_						-> fail $ c_mutf8Error i
		_		->	fail $ c_classError thisClassIndex



{-----------------------
 - --------------------
 - METHOD DISASSEMBLER 
 - --------------------
 -----------------------}

methodAccessFlags = [	(0x0001, PublicM),
											(0x0002, PrivateM),
											(0x0004, ProtectedM),
											(0x0008, StaticM),
											(0x0010, FinalM),
											(0x0020, SynchronizedM),
											(0x0040, BridgeM),
											(0x0080, VarArgsM),
											(0x0100, NativeM),
											(0x0400, AbstractM),
											(0x0800, StrictM),
											(0x1000, SyntheticM)		]

----
-- Signature Disassembler
----

simpleFieldType = do
	c <- anyChar
	case c of
		'B'		-> return Jbyte
		'C'		-> return Jchar
		'D'		-> return Jdouble
		'F'		-> return Jfloat
		'I'		-> return Jint
		'J'		-> return Jlong
		'S'		-> return Jshort
		'Z'		-> return Jbool
		_			-> fail "not a simple java type."

arrayFieldType = do
	char '['
	rest <- fieldType
	return $ Jarray rest

classFieldType = do
	char 'L'
	c <- manyTill anyChar (char ';')
--	c	<- between (string "L") (many1 anyChar) (string ";")
	return $ Jclass c

fieldType = try simpleFieldType
				<|> try arrayFieldType
				<|> try classFieldType
				<?> "not a field type"
--

fieldReturnType = do
	t <-	fieldType
	return $ MRT t

voidReturnType = do
	char 'V'
	return Void

returnType = 	try fieldReturnType
					<|>	try voidReturnType

methodSignature = do
	char '('
	args 	<- many fieldType
	char ')'
	ret 	<- returnType
	return (args, ret)

methodSignatureAttribute cp = do
	length <- u4
	if (length /= 2) 	then fail $ "found signature attribute's length " ++ show length ++ ", expecting 2"
										else do
												sigIndex <- u2
												case (entryAtIndex sigIndex cp) of
														MUtf8 sig	->	do
																						let signature = runParser methodSignature "" "" sig
																						case signature of
																							Right s	->	return $ MSA $ MT s
																							Left 	e	->	return $ MSA $ IgnoredMT sig
	-- $ 	"Unrecognized signature " ++ sig ++ ".\n"++ (unwords $ map messageString  (errorMessages e))
														_					->	fail $ c_mutf8Error sigIndex

---
--
---

syntheticMethodAttribute = do
	length <- u4
	if (length /= 0) 	then fail $ "found synthetic attribute's length " ++ show length ++ ", expecting 0"
										else return SyntheticMA

deprecatedMethodAttribute = do
	length <- u4
	if (length /= 0) 	then fail $ "found deprecated attribute's length " ++ show length ++ ", expecting 0"
										else return DeprecatedMA

---
-- Exceptions are not to be confused with the ones from 
-- the exception table: this attribute refers to exceptions
-- a the method may throw, while the latter refer to the code 
-- attribute.
---
extractException cp = do
	exceptionIndex <- u2
	case (entryAtIndex exceptionIndex cp) of
		C i	-> case (entryAtIndex i cp) of
							MUtf8 s	-> return s
							_				-> fail $ c_mutf8Error i
		_		-> fail $ c_classError exceptionIndex

disassembleExceptionsAttribute cp = do
	length <- u4
	exceptionsCount <- u2
	exceptions <- if (exceptionsCount == 0) 
									then return []
									else mapM (\_ -> do {e <- extractException cp; return e}) [1..exceptionsCount]
	return $ ME exceptions

skipMethodAttribute s = do	
	length <- u4
	mapM (\_ -> u1) [1..length]
	return $ UnknownMA s



{---------------------
 - ------------------
 - CODE DISASSEMBLER
 - ------------------
 ---------------------}

disassembleExceptionTableEntry cp = do
	start 			<- u2
	end					<- u2
	handler			<- u2
	classIndex	<- u2
	if (classIndex == 0)
		then return (start, end, handler, AnyException)
		else case (entryAtIndex classIndex cp) of
			C i		-> case (entryAtIndex i cp) of
								MUtf8 s	-> return (start, end, handler, EC s)
								_				-> fail $ c_mutf8Error i
			_			-> fail $ c_classError classIndex

skipCodeAttribute s= do
	length <- u4
	mapM (\_ -> u1) [1..length]
	return $ UnknownCA s

readCode :: Int -> JParser [Int]
readCode length = 	mapM (\_ -> do{i <- u1; return i}) [1..length]

-- Since attributes are not required, just skip them
disassembleCodeAttribute :: ConstantPool -> JParser CodeAttribute
disassembleCodeAttribute cp = do
	nameIndex <- u2
	case (entryAtIndex nameIndex cp) of
		MUtf8 s	-> skipCodeAttribute s
		_			-> fail $ c_mutf8Error nameIndex

disassembleMethodCodeAttribute :: ConstantPool -> String-> JParser MethodAttribute --XXX:HERE
disassembleMethodCodeAttribute cp name = do ---XXX:HERE
	attributeLength 		<- u4
	maxStack 						<- u2
	maxLocals 					<- u2

	codeLength	<- u4
	rawCode <- readCode codeLength
	code 		<- disassembleCode rawCode codeLength cp name --XXX:HERE
	exceptionTableLength <- u2
	exceptionTable 			 <- if (exceptionTableLength == 0)
														then return Nothing
														else do
															et <- mapM (\_ -> disassembleExceptionTableEntry cp) [1..exceptionTableLength]
															return $ Just $ ET et
	
	attributesCount <- u2
	attributes 			<- if (attributesCount == 0)
											then return []
											else mapM (\_ -> disassembleCodeAttribute cp) [1..attributesCount]
	
	return $ MC (code, (maxStack, maxLocals), exceptionTable, attributes)  -- XXX: COMPLETA

----
--
----
--
----

disassembleMethodAttribute cp name = do --XXX:HERE
 nameIndex <- u2
 case (entryAtIndex nameIndex cp) of
		MUtf8	"Synthetic"				-> syntheticMethodAttribute
		MUtf8	"Signature"				-> methodSignatureAttribute cp
		MUtf8	"Deprecated"			-> deprecatedMethodAttribute
		MUtf8 "Code"						-> disassembleMethodCodeAttribute cp name --XXX:HERE
		MUtf8	"Exceptions"			-> disassembleExceptionsAttribute cp
		MUtf8	s									-> skipMethodAttribute s

----
splitMethodAttributes :: [MethodAttribute] -> (Maybe MethodAttribute, [MethodAttribute])
splitMethodAttributes	[]					= (Nothing , [])
splitMethodAttributes ((MC x) :t) = (Just (MC x), t)
splitMethodAttributes (h:t)				= (code, rest)
																		where
																			(maybeCode, tail) = splitMethodAttributes t
																			code = case maybeCode of
																				Nothing 	-> Nothing
																				Just x		-> Just x
																			rest = h : tail

disassembleMethod :: ConstantPool -> JParser JMethod
disassembleMethod cp = do
	accessFlagsMask	<- u2
	nameIndex				<- u2
	descriptorIndex	<- u2
	attributesCount	<- u2
	let flags = maskToFlags	accessFlagsMask methodAccessFlags
	attributes <- if (attributesCount <= 0) 
									then	return []
									else mapM (\_ -> disassembleMethodAttribute cp (case (entryAtIndex nameIndex cp) of {MUtf8 s -> s; _ -> error "asdfasdfasdfasdf"})) [1..attributesCount] --XXX:HERE - REMOVE case
	--stackMaps				<- calculateStackMaps attributes
	--attributes <- stackMaps : attributes
	case (entryAtIndex nameIndex cp) of
		MUtf8 name	-> case (entryAtIndex descriptorIndex cp) of
			MUtf8 rawSignature	->	do 
														let signature = runParser methodSignature "" "" rawSignature
														let (code, attr) = splitMethodAttributes attributes
														case signature of
															Right (args, ret) ->	return $ JM (name, (MT (args, ret), length args), flags, code, attr)
															Left	e						->	fail	$ "Unrecognized method signature " ++ rawSignature
																														++  ".\n" ++ (unwords $ map messageString  (errorMessages e))
			_									-> fail $ c_mutf8Error descriptorIndex
		_						-> fail $ c_mutf8Error nameIndex


-----
---
-----
---
-----

disassembleAttribute cp = do
	nameIndex <- u2
	length		<- u4
	case (entryAtIndex nameIndex cp) of
		MUtf8 name	->	do
											mapM (\_ -> u1) [1..length]
											return $ UnknownMA name
		_						->	fail $ c_mutf8Error nameIndex

{-----------------------
 - ---------------------
 - .CLASS DISASSEMBLER 
 - ---------------------
 -----------------------}
classDisassembler :: CharParser String (String, JClass)
classDisassembler = do
	magicNumber
	v <- classVersion
	cp <- disassembleConstantPool 
	(this, flags, super, interfaces) <- disassembleMetadata cp
	
	fieldsCount			<- u2
	fields <- if (fieldsCount <= 0) 
											then return []
											else mapM (\_ -> do {f <- disassembleField cp; return f}) [1..fieldsCount]
	methodsCount		<- u2
	methods					<- if (methodsCount == 0)
											then return []
											else mapM (\_ -> do {m <- disassembleMethod cp; return m}) [1..methodsCount]
	attributesCount	<- u2
	attributes 			<- if (attributesCount == 0)
											then return []
											else mapM (\_ -> do {a <- disassembleAttribute cp; return a}) [1..attributesCount]
	contents 		<- getState
	return $ (contents, JC  (JMeta (this, flags, super, interfaces, v, [])) cp (JB fields methods))
	

--
--



modifyMethodCodeAttribute cp name = do ---XXX:HERE
	preAttrLength <- getState
	setState ""
	attributeLength 		<- u4
	setState ""

	maxStack 						<- u2
	maxLocals 					<- u2

	codeLength	<- u4
	rawCode <- readCode codeLength
	code 		<- disassembleCode rawCode codeLength cp name --XXX:HERE
	exceptionTableLength <- u2
	exceptionTable 			 <- if (exceptionTableLength == 0)
														then return Nothing
														else do
															et <- mapM (\_ -> disassembleExceptionTableEntry cp) [1..exceptionTableLength]
															return $ Just $ ET et
	
	--
	upToCode <- getState
	setState ""

	attributesCount <- u2
	setState ""
	
	attributes 			<- if (attributesCount == 0)
											then return []
											else mapM (\_ -> disassembleCodeAttribute cp) [1..attributesCount]
	upToAttributes	<- getState

	return $ ((preAttrLength, upToCode, Just (attributeLength, attributesCount), upToAttributes), MC (code, (maxStack, maxLocals), exceptionTable, attributes))


modifyMethodAttribute cp name = do --XXX:HERE
 nameIndex <- u2
 case (entryAtIndex nameIndex cp) of
		MUtf8	"Synthetic"		-> do	a <- syntheticMethodAttribute ; c <- getState; setState ""; return (("",c, Nothing,""),a)
		MUtf8	"Signature"		-> do	a <- methodSignatureAttribute cp; c <- getState; setState ""; return (("",c, Nothing,""),a)
		MUtf8	"Deprecated"	-> do	a <- deprecatedMethodAttribute; c <- getState; setState ""; return (("",c, Nothing,""),a)
		MUtf8 "Code"				-> do a <- modifyMethodCodeAttribute cp name; 			 setState ""; return a --XXX:HERE
		MUtf8	"Exceptions"	-> do	a <- disassembleExceptionsAttribute cp; c <- getState; setState ""; return (("",c,Nothing,""),a)
		MUtf8	s							-> do	a <- skipMethodAttribute s; c <- getState; setState ""; return (("",c, Nothing,""),a)

modifyMethod cp = do
	accessFlagsMask	<- u2
	nameIndex				<- u2
	descriptorIndex	<- u2
	attributesCount	<- u2
	let flags = maskToFlags	accessFlagsMask methodAccessFlags
	parsedMethod <- getState
	setState ""
	attributes <- if (attributesCount <= 0) 
									then	return []
									else mapM (\_ -> modifyMethodAttribute cp ((\(MUtf8 s) -> s) (entryAtIndex nameIndex cp))) 
														[1..attributesCount]
	let modifiedAttributes = map fst attributes
	let parsedAttributes	 = map snd attributes
	case (entryAtIndex nameIndex cp) of
		MUtf8 name	-> case (entryAtIndex descriptorIndex cp) of
			MUtf8 rawSignature	->	do 
														let signature = runParser methodSignature "" "" rawSignature
														let (code, attr) = splitMethodAttributes parsedAttributes
														case signature of
															Right (args, ret) ->	return $ (parsedMethod, modifiedAttributes)
															Left	e						->	fail	$ "Unrecognized method signature " ++ rawSignature
																														++  ".\n" ++ (unwords $ map messageString  (errorMessages e))
			_									-> fail $ c_mutf8Error descriptorIndex
		_						-> fail $ c_mutf8Error nameIndex


modifyClass :: JParser (String, [(String, [(String, String, Maybe (Int, Int), String)])], String)
modifyClass = do
	magicNumber
	v <- classVersion
	--cp <- disassembleConstantPool
	cp <- disassembleAndModifyConstantPool
	(this, flags, super, interfaces) <- disassembleMetadata cp

	fieldsCount			<- u2
	fields <- if (fieldsCount <= 0) 
											then return []
											else mapM (\_ -> do {f <- disassembleField cp; return f}) [1..fieldsCount]
	methodsCount		<- u2
	-- Save initial data
	upToMethodsCount <- getState
	setState ""
	-- Leave space to insert a stackMapTable in each method
	methodStrings		<- if (methodsCount == 0)
											then return []
											else mapM (\_ -> do {m <- modifyMethod cp; return m}) [1..methodsCount]
--let	methodStrings = map fst methodStringsAndMethods
--	let	methods 			= map snd methodStringsAndMethod
	setState ""
	attributesCount	<- u2
	attributes 			<- if (attributesCount == 0)
											then return []
											else mapM (\_ -> do {a <- disassembleAttribute cp; return a}) [1..attributesCount]
	upToAttributes 		<- getState
	return $ (upToMethodsCount, methodStrings ,upToAttributes)
