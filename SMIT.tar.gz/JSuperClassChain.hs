--module JReconstructor (buildClassHierarchy, joinSuperClassChains) where
module JSuperClassChain where

import Text.ParserCombinators.Parsec
import System.IO 
import System.IO.Error
import JClassData
import JDisassembler
import System.Posix.Files
import Control.Monad.State
import Data.Array 
import Data.List
import Data.Tree
import Data.HashTable
import Data.Maybe (catMaybes, isJust)

{---------------------------
 - ------------------------
 - ENVIRONMENT CONSTRUCTUR
 - ------------------------
 ---------------------------}
-- classesInCP helper function 
isAClassEntry cp rest i = case entryAtIndex i cp of
	C mutf8_index ->	
		case entryAtIndex mutf8_index cp of
			MUtf8 s ->  rest ++ [s]
			_       -> fail $ c_mutf8Error mutf8_index
	_       -> rest

-- Get Class entries from the constant pool
classesInCP cp  = foldl (isAClassEntry cp) [] [start..end]
									where
										(start, end) = bounds cp


-- Separate's path helper function
_separatePaths paths accumulator = case paths of
	[]      -> [accumulator]
	';': t  -> accumulator :  _separatePaths t []
	x  : t  -> _separatePaths t (accumulator ++ [x])

-- Separates a list of strings separated by a ';' and returns a list of that strings.
separatePaths paths = _separatePaths paths []


-- add trailing '\' to a posix path
addTrailing :: String -> String
addTrailing path = case last path of
	'/'	->	path
	_		->	path ++ ['/']


findFile :: String -> [String] -> IO (Maybe String)
findFile name [] 				= return Nothing
findFile name (p:paths) = do
	fileExists  <- System.IO.Error.try (fileAccess (p ++ name) True False False) --XXX: CHECK TRAILING / !!!!
	case fileExists of
		Left _	-> findFile name paths
		Right _	-> return $ Just $ p ++ name

dequalifyClassName (h:t)	= case h of
	'['	-> dequalifyClassName t
	'L'	-> 	className
					where
						classNameAndSemicolon = map (\a -> if a == '.' then '/' else a) t
						(className, end) =	splitAt (length t - 1) classNameAndSemicolon
	_		->	h:t
	

-- Disassemble a class given its name and possible paths in which the file can be found
getClass :: String -> [String] -> IO JClass
getClass className' libPaths = do
	let className = dequalifyClassName className'
	maybePath <- findFile (className ++ ".class") libPaths
	case maybePath of
		Nothing   -> fail $ "File " ++ className ++ ".class not found in the library paths:\n" ++ unlines libPaths
		Just path -> do
			content <- readFile path
			case runParser classDisassembler "" path content of
				Right (_, disassembledClass) 	-> return $ disassembledClass
				Left parseError								-> fail $ "Parsing class " ++ className ++ " failed.\n" ++ show parseError


prjClass_CA (JC (JMeta (_,CA flags,_,_,_,_)) _ _) = flags
prjClass_CN (JC (JMeta (CN n, _,_,_,_,_)) _ _) 		= n
prjClass_CP (JC (JMeta (_,_, super,_,_,_)) _ _) 	= super
prjCP 			(JC _ cp _) 													= cp

{- Superclass chain constructor
 - The superclass chain constructor builds the list
 - of parents of a given class, up to the Object class.
 - The algorithm recursively searches the parents in the classpaths
 - provided by the user. If no classpath has been specified
 - or the superclass is not found in the given classpaths, 
 - the algortihm searches in the classpaths defined in 
 - the constant _DEFAULT_CLASSPATHS.-}

superClassChain	::	String -> [String] -> IO [(String, JClass)]
superClassChain	className libPaths = do
	disassembledClass	<- getClass className libPaths
	if (elem InterfaceC (prjClass_CA disassembledClass))
		then return [(className, disassembledClass)]
		else	case prjClass_CP disassembledClass of
			Nothing								->	return [(className, disassembledClass)]
			Just (CP superClass)	->	do	
																	classChain <- superClassChain superClass libPaths
																	return $ (className, disassembledClass) : classChain
													
--type DisassembledClass = (String, JClass)
--type SuperClassChain = [DisassembledClass]
--type Environment		 = [(String, SuperClassChain)]

-- Build the environment of a class, that is the set of
-- classes in its constant pool plus the superclass chains of
-- each one.
getEnvironment :: ConstantPool -> String -> IO Environment
getEnvironment cp pathsString = do
	let trailinglessLibPaths = separatePaths pathsString
	let libPaths = map addTrailing trailinglessLibPaths
	let envClasses = nub $ classesInCP cp --  ++ ["java/lang/Cloneable", "java/io/Serializable"]
	env <- mapM (flip superClassChain $ libPaths) envClasses
	return $ zip envClasses env

{---------------------------
 - ------------------------
 - CLASS HIERARCHY BUILDER
 - ------------------------
 - -------------------------}
--type SearchKey = Int
--type ClassNode = (DisassembledClass, SearchKey)
--type ClassTree = Tree ClassNode

error_multipleRoots r 					= "Class Hierarchy building failed: multiple roots.\n" ++ unlines r
error_classRetrieval name 			= "Superclass Chain retriaval failed: class " ++ name ++ "not found.\n"
error_multiplePaths  name paths	= "Multiple paths found in the class hierarchy tree for class " ++ (\(a,b) -> a) name 
																	++":\n" ++ unlines (map (concat . map (\(a,b)->a)) paths)

-- Given a list of parent classes and corresponding child superclass chains, join the superchain c with
-- an existing parent or create a new couple parent-child
joinChain :: [(DisassembledClass, [SuperClassChain])] -> SuperClassChain -> [(DisassembledClass, [SuperClassChain])]
joinChain l [] = l
joinChain l c	= case findIndex (== ((\(a,b) -> a) $ head c)) chainNames of
		Just i 	-> zip chainHeads (take i chainTails ++ [((tail c) : (chainTails !! i))] ++ drop (i+1) chainTails)
		Nothing	-> (head c, [tail c]) : l
 where 
	chainHeads	= map (\(a, b) -> a) l
 	chainTails	= map (\(a, b) -> b) l
	chainNames	= map (\(a, b) -> a) chainHeads

joinChains c = foldl joinChain [] c

splitChildren children =  splitAt (div (length children - (mod (length children) 2)) 2) children

buildHierarchyTree :: (DisassembledClass, [SuperClassChain]) ->	Control.Monad.State.State Int (Tree ClassNode)
buildHierarchyTree chains = case chains of
	(leaf,	[])			-> do	
		i <- get
		put (i+1)
		return $ Node (leaf, i) []
	(parent, children) 	-> do
		let (firstHalf, secondHalf) = splitChildren children
		firstChildren 	<- mapM buildHierarchyTree (joinChains firstHalf)
		i <- get
		put (i+1)
		secondChildren	<- mapM buildHierarchyTree (joinChains secondHalf)
		return $ Node (parent, i) (firstChildren ++ secondChildren)

-- General purpose function, map a tree to another tree with the
-- given function f.
mapTree f t = case t of
	Node a []				->	Node (f a) []
	Node a subTree	->	Node (f a) (map (mapTree f) subTree)

collectKeys :: Tree ClassNode	->	[(String, Int)]
collectKeys t = case t of
	Node a []				->	[(fst $ fst a, snd a)]	
	Node a subTree	->	(fst $ fst a, snd a) : (concat $ map collectKeys subTree)

--Traverse the class hierarchy tree with the key i.
--While traversing, collect the nodes visited, forming thus the
--chain of superclasses of the class corresponding to i.
gatherChain :: Int -> (Int, Int) -> ClassTree -> Maybe SuperClassChain
gatherChain i bounds t = case t of
	Node (dclass, n) [] 	->	if (n == i)
														then Just [dclass]
														else Nothing
	Node (dclass, n) children	->	if (n == i)
														then Just [dclass]
														else 
															let (firstHalf, secondHalf) = splitChildren children in
																if (n < min || n > max)
																	then Nothing
																	else if (i < n)
																		then 
																			let lowerchain = catMaybes $ map (gatherChain i (min, n)) firstHalf in
																			case lowerchain of
																				[]	-> 	Nothing
																				[x]	->	Just (x ++ [dclass])
																				p		-> error $ error_multiplePaths dclass p 
																		else 
																			let lowerchain = catMaybes $ map (gatherChain i (n, max)) secondHalf in
																			case lowerchain of
																				[]	-> 	Nothing
																				[x]	->	Just (x ++ [dclass])
																				p		-> error $ error_multiplePaths dclass p
		where	
			(min, max) = bounds


-- Join two superclass chains into a list of common parents.
-- Note that there is always at least one parent,"java/lang/Object",
-- by construction.
joinSuperClassChains	:: SuperClassChain	->	SuperClassChain	->	SuperClassChain
joinSuperClassChains	a b	= reverse $ catMaybes $ 
														map (\(a1, a2) -> if ((\(a, b)->a) a1 == (\(a,b)->a) a2) then Just a1 else Nothing) 
														(zip c1 c2)
	where
		c1 = reverse a
		c2 = reverse b
	
{- Build the class hierarchy of all the classes mentioned in the environment of a class.
 - The root must be "java/lang/Object".-}
buildClassHierarchy :: Environment	->	IO (String -> IO (Maybe SuperClassChain))
buildClassHierarchy env = do
	-- project the class chains from the environment
	let prjChains				= map (reverse . snd)
	-- remove interfaces
	let prune						= concat . map (\a -> if (fst $ head a) == "java/lang/Object" then [a] else [])

	let chains					= prune $ prjChains env
	let getRoot scc 	= nub $ map (fst . head) scc
	start	<- if ((\[a]-> a) (getRoot chains) == "java/lang/Object") 
										then return $ joinChains chains
										else fail $ error_multipleRoots (getRoot chains)
	let (hierarchyTree, hierarchyTreeCount) = runState (buildHierarchyTree ((\[a] -> a) start)) 0

	classNamesHashtable <- fromList hashString $ collectKeys hierarchyTree
	let hierarchyTreeSearch c = do 
		i <- Data.HashTable.lookup classNamesHashtable c
		case i of 
			Just j 	-> return $  gatherChain j (0, hierarchyTreeCount) hierarchyTree
			Nothing	-> return Nothing
	return hierarchyTreeSearch	
