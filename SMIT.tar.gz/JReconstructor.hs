--module JReconstructor (buildClassHierarchy, joinSuperClassChains) where
module JReconstructor where

import Text.ParserCombinators.Parsec
--import Text.ParserCombinators.Parsec.Token
--import Text.ParserCombinators.Parsec.Prim (try)
-- import Text.ParserCombinators.Parsec.Error
import System.IO 
--import System.IO.Error
import JClassData
import JDisassembler
import JSuperClassChain
--import System.Posix.Files
import Control.Monad (foldM, when)
--import System.Posix.Env (getEnv)
--XXX: utility: parse env var
--import Data.Array 
import Data.List
--import Data.Tree
--import Data.HashTable
import Data.Maybe (catMaybes, isJust)

{---------------------------
 - ------------------------
 - JAVA VERIFIER SUBTYPING
 - ------------------------
 ---------------------------}
error_codeDivision t = "Code division in block failed for targets " ++ unwords (map show t) ++ "."
error_badSize	vtype	 = "Unrecognized size for type " ++ show vtype ++ "\n."

fail_frameUnassignable s1 s2 codeLine = "Type inference failed: cannot assign StackFrame " ++ show s1 ++ 
																				" to StackFrame " ++ show s2 ++ " at " ++ showCodeLine codeLine  ++"\n."

---

--type SuperClassSearcher = (String -> IO (Maybe SuperClassChain))


prjMethodArgsType	(JM (n, (mt,_), _, _, _)) 	= case mt of
	MT (argsType, _)	->	argsType
	IgnoredMT	s				->	error $ "Arguments type projection from method " ++ n ++ " failed: found ignored type " ++ s
prjMaxLocals (JM (_, _, _, Just (MC (_, (_,l),_,_)), _)) 	= l



jtypeToVtype t 
	= case t of
	Jbyte 			->	VTInteger
	Jchar 			->	VTInteger
	Jdouble 		->	VTDouble
	Jfloat			->	VTFloat
	Jint  			->	VTInteger
	Jlong 			->	VTLong
	Jbool   		->	VTInteger
	Jshort			->	VTInteger
	Jclass s 		->	VTClass s
	Jarray j		->	error "array not yet done." --

prjClassName (JC (JMeta (CN className, _,_,_,_,_))_ _) 	= className
prjMethodName (JM (methodName, _, _, _, _))							= methodName
prjMethodAccessFlags (JM (_, _, flags, _, _))						= flags

initialThisType	:: JClass	->	JMethod -> SuperClassChain -> Maybe ([VType], [VFlag])
initialThisType jclass jmethod superClassChain = 
	if (elem StaticM accessFlags)
		then if (methodName /= "<init>") -- Static method: no This type
					then Just ([], [])
					else Nothing
		else if (methodName /= "<init>")
					then Just $ ([VTClass className], [])
					else if (className == _JAVA_LANG_OBJECT) --  "java/lang/Object")
						then Just $ ([VTClass "java/lang/Object"], [])
						-- check if the superClass chain is
						else if	(length superClassChain /= 0)
							then Just $ ([VTUninitializedThis], [FlagThisUninit])
							else Nothing
	where
		className 	= prjClassName 	 jclass
		accessFlags = prjMethodAccessFlags jmethod
		methodName	=	prjMethodName	jmethod

-- Build the initial StackFrame. Note that this is an implicit frame, since it has to be calculated
-- from the method signature and not from the method code itself.
initialStackFrame :: JClass	->	JMethod	->	SuperClassSearcher -> IO	StackFrame
initialStackFrame jclass jmethod sccSearcher = do
	superClassChain' <- sccSearcher (prjClassName jclass)
	let superClassChain	=	case superClassChain' of
		Just x	->	x
		Nothing	->	error $ "Class hierarchy retrieval for class " ++ prjClassName jclass ++ "failed."
	let frameSize = prjMaxLocals jmethod
	
	let initTypeAndFlag = case initialThisType jclass jmethod superClassChain of
												Just x ->	x
												Nothing	->	error "Initial ThisType reconstruction failed."
	
	let initType	= fst initTypeAndFlag
	let initFlag  = snd initTypeAndFlag
	let argsType	= prjMethodArgsType jmethod
	
	let partialLocals = initType ++ map jtypeToVtype argsType
	let locals = if (length partialLocals > frameSize)
								then error "Initial StackFrame construction failed.\n Declared locals' size exceeds the maximum allowed."
								else partialLocals ++ (map (\a -> VTTop) [1..(frameSize - (length partialLocals))])
	return $ SF locals [] initFlag

---
-- Dividee the code in blocks
---

-- Extracts the list of targets of unconditional branhces from an instruction.
-- Note that TableSwitch and LookUp
extractJumpTarget :: CodeLine -> Maybe [Int]
extractJumpTarget	codeLine	= case snd codeLine of
	Goto 			i									->	Just [instructionOffset + i]
	GotoW 		i									-> 	Just [instructionOffset + i]
	IFACMPEQ	i									->	Just [instructionOffset + i]
	IFACMPNE	i									->	Just [instructionOffset + i]
	IFICMPEG	i									->	Just [instructionOffset + i]
	IFCMPNE		i									->	Just [instructionOffset + i]
	IFICMPLT	i									->	Just [instructionOffset + i]
	IFICMPGE	i									->	Just [instructionOffset + i]
 	IFICMPGT	i									->	Just [instructionOffset + i]
	IFICMPLE	i									->	Just [instructionOffset + i]
	IfEQ			i									->	Just [instructionOffset + i]
 	IfNE			i									->	Just [instructionOffset + i]
	IfLT			i									->	Just [instructionOffset + i]
	IfGE			i									->	Just [instructionOffset + i]
	IfGT 			i									->	Just [instructionOffset + i]
	IfLE 			i									->	Just [instructionOffset + i]
	IfNonNull i									->	Just [instructionOffset + i]
	IfNull 		i									->	Just [instructionOffset + i]
	LookUpSwitch def _	pairs		->	Just $ 	((fromIntegral def) + instructionOffset) : 
																					(map (\(a, i) -> (fromIntegral i) + instructionOffset) pairs)
	TableSwitch  def low high i	->	Just $ 	((fromIntegral def) + instructionOffset) : 
																					(map (\a -> (fromIntegral a) + instructionOffset) i)
	nonBranchingInstruction			->	Nothing
	where
		instructionOffset = fst codeLine


extractAfterReturnTargets (i, instruction) = case instruction of
	AReturn	->	Just (i + 1)
	DReturn	->	Just (i + 1)
	FReturn	->	Just (i + 1)
	IReturn	->	Just (i + 1)
	LReturn	->	Just (i + 1)
	Return	->	Just (i + 1)
	_	->	Nothing



divideCodeBlocks :: [ExceptionHandler]	->	MethodCode	->	[MethodCode]
divideCodeBlocks eHandlers code =
	let jumpTargets = sort $ nub $ concat $ catMaybes $ map extractJumpTarget code in
		let targets = jumpTargets ++ (map (\(_,_,a,_) ->a) eHandlers)	in
			let returnTargets = catMaybes $ map (\a -> if a < length code - 1 then Just a else Nothing ) $ catMaybes $map extractAfterReturnTargets code	in
				if (and (map (\a -> elem a targets) returnTargets))
					then	blockDivider targets [] code
					else error "error in return instruction positions"
		where
			blockDivider t						 _				[]													 = error $ error_codeDivision t 
			blockDivider [] 					 curBlock	code 												 = [curBlock ++ code]
			blockDivider (target:tail) curBlock ((offset, instruction):code) = if target == offset 
				then curBlock : (blockDivider tail [(offset, instruction)] code )
				else blockDivider (target:tail) (curBlock ++ [(offset, instruction)]) code

addChangedFlag = map (\a -> (a, True))

{--------------------------------------
 - -----------------------------------
 - ISASSIGNALE - JAVA VTYPE SUBTYPING
 - -----------------------------------
 --------------------------------------}

-- Chech if class or array x can is a subtype of class or array y
-- under the Java language subtyping rules.
isJavaAssignable	sccSearcher x y = case x of
		-- Class case
		VTClass c_x	-> case y of
			VTClass c_y	-> do 
									scc_y	<-	sccSearcher c_y
									case scc_y of
										Nothing 				-> return True 	--Interface Case
										Just superCC_y	-> do						--isJavaSubClass case
											scc_x	<- sccSearcher c_x
											case scc_x of
												Nothing -> return False
												Just superCC_x	->	do
													if elem (c_y) (map fst superCC_x)
														then return True
														else return False
			_						->	return False
		--Array case
		VTArray a_x	-> case y of 
			VTClass c												-> if (	c == _JAVA_LANG_OBJECT			||
																							c == "java/lang/Cloneable"	||
																						 	c == "java/io/Serializable"	)
																						then return True
																						else return False
			VTArray a_y	->	do
				let simpleTypes = [VTInteger, VTFloat, VTLong, VTDouble]
				if (elem a_y simpleTypes) && (elem a_x simpleTypes) && (a_y == a_x)
					then return True
					else do
						javaAssignable <- isJavaAssignable sccSearcher a_x a_y
						return javaAssignable
		--If it is not a class or an array, return false because the previous
		--rules failed.
			_	->	return False
		_						->	return False
-- Get the chain of supertypes of a verification typw.
-- This corresponds to the first subtyping rules presented
-- in JSR 202.
getSuperVTypeChain :: VType -> [VType]
getSuperVTypeChain	x	=	case x of
	VTTop										->	[VTTop]
	VTOneWord								->	VTOneWord  	: getSuperVTypeChain VTTop
	VTTwoWords							->	VTTwoWords 	: getSuperVTypeChain VTTop
	VTInteger								->	VTInteger 	: getSuperVTypeChain VTOneWord
	VTFloat									->	VTFloat 		: getSuperVTypeChain VTOneWord
	VTLong									->	VTLong 			: getSuperVTypeChain VTTwoWords
	VTDouble								->	VTDouble 		: getSuperVTypeChain VTTwoWords
	VTReference							->	VTReference	: getSuperVTypeChain VTOneWord
	VTClass c								->	VTClass c		: getSuperVTypeChain VTReference
	VTArray a								->	VTArray a		: getSuperVTypeChain VTReference --XXX:Shouldn't this be child of Object?
	--Note: This is the last of the 3 cases for VTNull. 
	VTNull									-> 	VTNull 			: getSuperVTypeChain (VTClass _JAVA_LANG_OBJECT)
	VTUninitialized					->	VTUninitialized 				:	getSuperVTypeChain	VTReference
	VTUninitializedThis			->	VTUninitializedThis			:	getSuperVTypeChain	VTUninitialized
	VTUninitializedOffset o	->	VTUninitializedOffset o	:	getSuperVTypeChain	VTUninitialized



uninitIsAssignable :: SuperClassSearcher -> VType -> VType -> IO Bool
-- Null: 2/3 cases; if it is a class or arraym it is assignable
uninitIsAssignable _ VTNull (VTClass _) = return True
uninitIsAssignable _ VTNull (VTArray _) = return True
--Other cases
uninitIsAssignable sccs x y = do
	let xSuperTypeChain = getSuperVTypeChain x
	if (elem y xSuperTypeChain)
		then return True
		else do
			javaAssignable <- isJavaAssignable sccs x y
			return javaAssignable
	
-- Returns the size of a verification type
uninitSizeOf :: SuperClassSearcher -> VType -> IO Int
uninitSizeOf sccs x = do
	let isAssignable = uninitIsAssignable sccs
	if x == VTTop
		then return 1
		else do
			isOneWord	<- isAssignable x VTOneWord
			if isOneWord
				then return 1
				else do
				isTwoWords	<-	isAssignable x VTTwoWords
				if isTwoWords
					then return 2
					else error $ "Size calculation failed for unexpected type " ++ show x ++ ".\n"

-- StackFrame subtyping is extended point-wise.
uninitFrameIsAssignable	:: SuperClassSearcher -> StackFrame -> StackFrame -> IO Bool
uninitFrameIsAssignable	sccs (SF l1 s1 f1) (SF l2 s2 f2) = do
	let isAssignable	= uninitIsAssignable sccs

	let	sameLength = length s1 == length s2
	let subsetFlag = if f1 == []
										then True
										else if f2 == [FlagThisUninit]
											then True
											else False
	assignableLocals 	<-	mapM (\(a,b) -> isAssignable a b) (zip l1 l2)
	assignableStack		<-	mapM (\(a,b) -> isAssignable a b) (zip s1 s2)

	if sameLength && (and assignableLocals) && (and assignableStack) && subsetFlag
		then return True
		else return False

{----------------------
 - -------------------
 - EXCEPTION HANDLING
 - -------------------
 ----------------------}


uninitTargetIsTypeSafe	:: SuperClassSearcher -> (Offset -> Maybe StackFrame) -> StackFrame -> Target -> IO Bool
uninitTargetIsTypeSafe	sccs offsetToStackFrame stackFrame target = do
	let maybeOffsetFrame	=  offsetToStackFrame target
	case maybeOffsetFrame of
		Just offsetFrame 	-> do
													assignable	<-	uninitFrameIsAssignable sccs stackFrame offsetFrame	
													return assignable
		Nothing						-> return True	--XXX: NOTE ENOUGH INFO: ASSUME YES


instructionSatisfiesHandler	:: SuperClassSearcher	->  StackFrame	-> (Offset -> Maybe StackFrame) -> ExceptionHandler -> IO Bool
instructionSatisfiesHandler	sccs stackFrame offsetToStackFrame exceptionHandler	= do
	let (SF locals _ flags) 	= stackFrame
	let (_, _, target, etype) = exceptionHandler
	let exceptionClass = case etype of
		AnyException	->	VTClass "java/lang/Throwable"
		EC s					->	VTClass s
	safe  <-	uninitTargetIsTypeSafe	sccs offsetToStackFrame (SF locals [exceptionClass] flags) target
	return safe

---
--
---

prjExceptionTable	(JM (_, _, _, Just (MC (_, _, Just et, _)), _))	=	Just et
prjExceptionTable	(JM (_, _, _, Just (MC (_, _, Nothing, _)), _))	=	Nothing
prjExceptionTable	(JM (_, _, _, Nothing, _)											) =	Nothing

getHandlers :: ExceptionTable	-> [ExceptionHandler]
getHandlers	(ET t) = t

selectHandlersAt :: Target -> [ExceptionHandler]	-> [ExceptionHandler]
selectHandlersAt offset handlers =
	let handlerSelector (from, to, target, etype) = if (offset >= from) && (offset < to) 
																										then Just (from, to, target, etype)
																										else Nothing	in
		catMaybes $ map handlerSelector handlers

---
--
---

instructionSatisfiesHandlers	:: SuperClassSearcher	-> JMethod	->	Int -> StackFrame	-> (Offset -> Maybe StackFrame) -> IO Bool
instructionSatisfiesHandlers	sccs jmethod offset stackFrame offsetToStackFrame=	do
	let eTable = prjExceptionTable jmethod
	case eTable	of
		Just exceptionTable	-> do
			let eHandlers	= getHandlers exceptionTable
			let handlers	= selectHandlersAt offset eHandlers
			satisfy	<- mapM (instructionSatisfiesHandler sccs stackFrame offsetToStackFrame) handlers
			return $ and satisfy
		Nothing							->	return True



handlerIsLegal ::	SuperClassSearcher	-> JMethod	-> (Offset -> Maybe StackFrame) -> ExceptionHandler	->  IO Bool
handlerIsLegal	sccs jmethod offsetToHandler eHandler	= do
	let (from, to, target,  exceptionType) = eHandler
	if (from < to)
		then case offsetToHandler target of
			Just _	->	do
				let prjMC (JM (_,_,_,c,_)) = c
				case prjMC jmethod of
					Just codeAttr ->	do
						let prjCode (MC (x,_,_,_)) = x
						let code = prjCode codeAttr
						if (elem from (map fst code)) && (elem to (map fst code))
							then	do
								let exceptionVType = case exceptionType of
																				AnyException	->	VTClass "java/lang/Throwable"
																				EC s					->	VTClass s
								assignable	<- uninitIsAssignable sccs exceptionVType (VTClass "java/lang/Throwable")
								return assignable
							else return False
					Nothing	->	return False
			Nothing	->	return False
		else return False

handlersAreLegal :: SuperClassSearcher	-> JMethod	-> (Offset -> Maybe StackFrame)-> IO Bool
handlersAreLegal sccs jmethod	offsetToStackFrame = do
	case prjExceptionTable jmethod of
		Nothing -> return True
		Just et	->	do
			let handlers = getHandlers et
			legals <- mapM (handlerIsLegal sccs jmethod offsetToStackFrame) handlers
			return $ and legals



{------------------------
 - ---------------------
 - STACKFRAME UTILITIES
 - ---------------------
 ------------------------}

uninitPopMatchingType :: SuperClassSearcher -> VStack -> VType -> IO (Maybe (VStack, VType))
uninitPopMatchingType sccs stack vtype= do
	let sizeOf 				= uninitSizeOf sccs
	let isAssignable	= uninitIsAssignable sccs
	size <- sizeOf vtype
	case head stack of
		VTTop	->	if size == 2
								then do
									assignable <- isAssignable (head $ tail stack) vtype
									if assignable 
										then return $ Just $ (tail $ tail stack, head $ tail stack)
										else return Nothing
								else return Nothing--error "PopMatchingType failed: Stack Types mismatch."
		_			->	if size == 1
								then do
									assignable <- isAssignable (head stack) vtype
									if assignable
										then return $ Just $ (tail stack, head stack)
										else return Nothing
								else return Nothing

uninitPopMatchingList :: SuperClassSearcher -> VStack -> [VType] -> IO (Maybe VStack)
uninitPopMatchingList _		 stack []			= return $ Just stack
uninitPopMatchingList sccs stack vtypes = do
	poppedStack <- uninitPopMatchingType sccs stack (head vtypes)
	case poppedStack of
		Just (newStack, _)	-> uninitPopMatchingList sccs newStack (tail vtypes)
		Nothing							-> return Nothing



uninitPopCategory1 :: SuperClassSearcher -> VStack -> Maybe VType -> IO (Maybe (VStack, VType))
uninitPopCategory1 sccs stack maybeVType	=	do
	case head	stack of 
		VTTop	-> return Nothing
		_			->	do
								size <- uninitSizeOf sccs (head stack)
								if (size == 1) 
									then case maybeVType of
										Just vtype	-> 
											if (head stack == vtype)
												then return $ Just (tail stack, vtype)
												else return Nothing
										Nothing			-> return  $ Just (tail stack, head stack)
									else return Nothing

uninitPopCategory2 :: SuperClassSearcher -> VStack -> Maybe VType -> IO (Maybe (VStack, VType))
uninitPopCategory2 sccs stack maybeVType = do
	case head	stack of 
		VTTop	->	do
								size <- uninitSizeOf sccs (head $ tail stack)
								if (size == 2)
									then case maybeVType of
										Just vtype	->	if (vtype == (head $ tail stack))
												then return $ Just (tail $ tail stack, vtype)
												else return Nothing
										Nothing			->	return $ Just (tail $ tail stack, head $ tail stack)
									else return Nothing
		_			->	return Nothing


uninitPop :: SuperClassSearcher -> StackFrame -> [VType] -> IO (Maybe StackFrame)
uninitpop _						sf												[]			= return Nothing
uninitPop sccs (SF locals stack flags) vtypes 	= do
	newStack <- uninitPopMatchingList sccs stack vtypes
	case newStack of
		Just s	->	return $ Just $ SF locals s flags
		Nothing	->	return Nothing
	

uninitPushOperandStack	:: SuperClassSearcher -> VStack -> Maybe VType -> IO VStack
uninitPushOperandStack _		 stack Nothing		 = return stack
uninitPushOperandStack	sccs stack (Just vtype)= do
	size <- uninitSizeOf sccs vtype
	if size == 1 
		then return $ vtype : stack
		else if size == 2 
			then return $ VTTop : vtype : stack
			else error $ error_badSize vtype

prjMaxStack (JM (_, _,_, Just (MC (_, (s, _),_,_)),_)) = s

stackHasLegalLength :: JMethod -> VStack	-> IO Bool
stackHasLegalLength jmethod stack =	
--	putStrLn $ "DEBUG: StackSize = " ++ show (prjMaxStack jmethod) ++ "; stack length = " ++ show (length stack)
	if length stack <= (prjMaxStack jmethod)
		then return True
		else return False

uninitSafelyPush :: SuperClassSearcher -> JMethod -> VStack -> Maybe VType -> IO (Maybe VStack)
uninitSafelyPush sccs jmethod stack vtype = do
	newStack 	<- uninitPushOperandStack sccs stack vtype
	legal 		<- stackHasLegalLength jmethod newStack
	if legal
		then return $ Just newStack
		else return Nothing


uninitSafelyPushList	:: SuperClassSearcher -> JMethod -> VStack -> [Maybe VType]	-> IO (Maybe VStack)
uninitSafelyPushList	sccs jmethod stack vtypes= do
	newStack	<- uninitPushList sccs stack vtypes
	legal			<- stackHasLegalLength jmethod newStack
	if legal
		then return $ Just newStack
		else return Nothing

uninitPushList	:: SuperClassSearcher -> VStack	->	[Maybe VType]	-> IO VStack
uninitPushList 	_		 stack []			= return stack
uninitPushList	sccs stack (h:t)	= do
	tempStack <-	uninitPushOperandStack sccs stack h
	newStack	<-	uninitPushList	sccs tempStack t
	return newStack



uninitValidTypeTransition :: SuperClassSearcher -> JMethod -> [VType] -> Maybe VType -> StackFrame -> IO (Maybe StackFrame)
uninitValidTypeTransition sccs jmethod expectedTypes resultType (SF locals inputStack flags) = do
	tempStack <- uninitPopMatchingList sccs inputStack expectedTypes
	case tempStack of
		Just tStack	->	do
			newStack	<- uninitPushOperandStack	sccs tStack resultType
--			putStrLn $ "DEBUG: ValidTypeTransition: newStack = " ++ show newStack
			legal <- stackHasLegalLength jmethod newStack
			if legal
				then return $ Just $ SF locals newStack flags
				else return Nothing
		Nothing	->	return Nothing
	

uninitLoadIsTypeSafe :: SuperClassSearcher -> JMethod	->	Int	-> Maybe VType	-> StackFrame	-> IO (Maybe StackFrame)
uninitLoadIsTypeSafe	sccs jmethod index vtype	(SF locals stack flags) = do
	let stackFrame	=	SF locals stack flags
	let ithLocal 		= locals !! index
	assignable			<- case vtype of	
												Just vt	->	uninitIsAssignable sccs ithLocal vt
												Nothing -> 	return False
	if assignable
		then do
			nextStackFrame	<- uninitValidTypeTransition sccs jmethod [] (Just ithLocal) stackFrame
			return nextStackFrame
		else return Nothing


--
---
--	Helper function for uninitModifyLocalVariable
---
--

modifyPreIndexVariable	:: SuperClassSearcher	->	VType	->	IO	VType
modifyPreIndexVariable sccs vtype = do
	size <- uninitSizeOf sccs vtype
	case size of 
		1 ->	return vtype
		2 ->	return VTTop
		_	->	error $ error_badSize vtype 


modifyLocals i sccs index vtype (h:t)
--Not near the index yet
	| i < index - 1	= do
			otherLocals <- modifyLocals (i+1) sccs index vtype t
			case otherLocals of
				Nothing	->	return Nothing
				Just l	->	return $ Just (h : l)
--Before the index one
	| i == index -1 = do
			preLocal 		<- modifyPreIndexVariable sccs h
			otherLocals <- modifyLocals (i+1) sccs index vtype t
			case otherLocals of
				Nothing ->	return Nothing
				Just l	->	return $ Just (preLocal : l)
--Arrived at index
	| i == index = do
			size <- uninitSizeOf sccs vtype
			case size of
				1 -> return $ Just $ vtype : t
				2 ->	do
						if length t > 0
							then return $ Just $ vtype : VTTop : (tail t)
							else return Nothing
				_	-> error $ error_badSize vtype
	| otherwise = return Nothing

uninitModifyLocalVariable :: SuperClassSearcher -> Int -> VType -> VLocal -> IO (Maybe VLocal)
uninitModifyLocalVariable sccs index vtype locals	=
	modifyLocals 0 sccs index vtype locals


uninitStoreIsTypeSafe	:: SuperClassSearcher	-> Int -> VType -> StackFrame -> IO (Maybe StackFrame)
uninitStoreIsTypeSafe sccs index vtype (SF locals stack flags) = do
	stackAndType <- uninitPopMatchingType sccs stack vtype
	case stackAndType of
		Just s	->	do
			let (newStack, actualType) = s
			newLocals <- uninitModifyLocalVariable sccs index actualType locals
			case newLocals of
				Nothing -> return Nothing
				Just l	-> return $ Just $ SF l newStack flags
		Nothing	-> return Nothing
	
-- Function to expand a verification type list to the java representation as 32 bit words
expandTypeElement sccs vtype = do
	size <- uninitSizeOf sccs vtype
	case size of
		1 -> return [vtype]
		2 -> return [vtype, VTTop]
		_	-> error $ error_badSize vtype

expandTypeList	:: SuperClassSearcher	->	[VType]	-> IO [VType]
expandTypeList sccs typeList = do
	expandedList <- mapM (expandTypeElement sccs) typeList
	return (concat expandedList)


exceptionStackFrame :: StackFrame	->	StackFrame
exceptionStackFrame (SF locals _ flags) = SF locals [] flags



{---------------------
 - ------------------
 - STACKMAP CREATION
 - ------------------
 ---------------------}
 -- collect the initial offset and the StackFrame of each code block, and 
 -- return a function from offset to StackFrame
offsetToSF b i = foldl (\acc (a, b) -> if a == i then b else acc) 
												Nothing 
												(map (\(block, frame, _) -> (fst $ head block, frame)) b)

unmarkBlock	block blocks= map (\(unmarkedBlock, frame, bool) -> if block == unmarkedBlock
																																		then (block, frame, True)	
																																		else (unmarkedBlock, frame, bool))
															blocks

updateBlock frameIsAssignable code maybeBlockStackFrame incomingTypeState = do
	let blockStackFrame = case maybeBlockStackFrame of
												Just x->x
												Nothing -> error $ "Internal error: update block on no blockStackFrame"
	oldValid	<- frameIsAssignable incomingTypeState blockStackFrame
	if oldValid
		-- The new type state offers no more information than the previous one: discard it
		then do
			return maybeBlockStackFrame
		else do
			changeable	<- frameIsAssignable	blockStackFrame	incomingTypeState
			if changeable
				-- The new type state is more informative: discard the old stack frame
				then do
					return  $ Just incomingTypeState
				--	The stack frames are incompatible: type inference fails.
				else	fail $ fail_frameUnassignable blockStackFrame incomingTypeState (head code)

updateBlocks	_							[]	_					= return []
updateBlocks	frameIsAssignable (block:t) update = do
	let (code, maybeBlockStackFrame, bool) = block

	let updatedOffsets		=	 map fst update
	let	firstCodeOffset 	=	fst $ head code
	
	if elem firstCodeOffset updatedOffsets
		then do
			let incomingTypeStates = nub $ catMaybes $ map (\(i,sf) -> if i == firstCodeOffset then Just sf else Nothing) update
			case maybeBlockStackFrame of
				Just blockStackFrame	->do
					updatedStackFrame <- foldM	(updateBlock frameIsAssignable code) maybeBlockStackFrame incomingTypeStates
					let updatedBlock = if updatedStackFrame == maybeBlockStackFrame
															then (code, maybeBlockStackFrame, bool)
															else (code, updatedStackFrame, False)
					updatedBlocks	<- updateBlocks frameIsAssignable t update
					return $ updatedBlock : updatedBlocks
					{-oldValid	<- frameIsAssignable incomingTypeState blockStackFrame
					if oldValid
						-- The new type state offers no more information than the previous one: discard it
						then do
							updatedBlocks	<- updateBlocks frameIsAssignable t update
							return $ (code, maybeBlockStackFrame, True) : updatedBlocks
						else do
							changeable	<- frameIsAssignable	blockStackFrame	incomingTypeState
							if changeable
								-- The new type state is more informative: discard the old stack frame
								then do
									updatedBlocks	<- updateBlocks frameIsAssignable t update
									return  $ (code, Just incomingTypeState, False):updatedBlocks
								--	The stack frames are incompatible: type inference fails.
								else	fail $ fail_frameUnassignable blockStackFrame incomingTypeState (head code)-}
				-- No stack frame available at this block: substitute it with the first incoming type state
				-- and check if remaining ones type-match
				Nothing	->	do
					let updatedBlocks = (code, Just $ head incomingTypeStates, False) : t
					u <- updateBlocks frameIsAssignable updatedBlocks update
					let (code, sf, _) = head u
					return $ (code, sf, False) : (tail u)
					--updatedBlocks	<- updateBlocks frameIsAssignable t update
					--return r
		else do
			updatedBlocks	<- updateBlocks frameIsAssignable t update
			return $ block : updatedBlocks
	
	

getUnprocessedBlock	[]							= (Nothing, Nothing)
getUnprocessedBlock	((c,f,True):t) 	= getUnprocessedBlock t
getUnprocessedBlock	((c,f,False):t) = (Just (c,f,False), followingBlock)
	where followingBlock = if length t > 0 then Just $ head t else Nothing

--
----
----
--

stackFramesInference :: (StackFrame -> StackFrame -> IO Bool) ->
												((Maybe StackFrame, Maybe StackFrame, [(Int, StackFrame)]) -> CodeLine 
												-> IO (Maybe StackFrame, Maybe StackFrame, [(Int, StackFrame)]))	->
												[(MethodCode, Maybe StackFrame, Bool)]	->	IO [StackFrame]

stackFramesInference frameIsAssignable inferSF markedCodeBlocks = do
	-- get the first block whose type state has been changed
	let (maybeBlock, followingBlock)	=	getUnprocessedBlock markedCodeBlocks
--	putStrLn $ "DEBUGGING: code blocks:\n"  ++ unlines (map show markedCodeBlocks) ++ "\n-----------\n"
	case maybeBlock of
		-- Update StackFrame information
		Just (codeBlock, stackFrame, _)	->	do
			-- Mark the chosen block as processed
			let unmarkedCodeBlocks = unmarkBlock codeBlock markedCodeBlocks
	--		putStrLn $ "DEBUGGING: unmarked code blocks:\n"  ++ unlines (map show markedCodeBlocks) ++ "\n-----------\n"
			-- Calculate by type inference the last StackFrame of a block and the new
			-- incoming type states for other blocks
			inferredSF	<-	foldM	inferSF (stackFrame, Nothing, []) codeBlock
			let (lastFrame, _, incomingTypeStates') = inferredSF
			-- Check if the incoming type states also modify the code block following the one in exam
			let incomingTypeStates = case lastFrame of
													Nothing			->	incomingTypeStates'
													Just frame	->	case followingBlock of
																				Nothing	->	error "Unexpected end of code"
																				Just fb	->	(fst $ head $ (\(a,b,c) -> a) fb, frame) : incomingTypeStates'
--			putStrLn $ "DEBUGGING:\n" ++ "inferred last frame = " ++ show lastFrame ++ "\nIncomingTypeStates = " ++ unlines (map show incomingTypeStates) ++ "\n.---------------------------\n"
			updatedBlocks	<-	updateBlocks frameIsAssignable unmarkedCodeBlocks incomingTypeStates
			--
			r <- stackFramesInference frameIsAssignable inferSF updatedBlocks
			return r
		-- Nothing: fix-point reached
		Nothing	->	return $ catMaybes $ map (\(block, frame, _) -> frame) markedCodeBlocks 

--
--
--

createStackFrames	::	SuperClassSearcher -> JClass -> JMethod -> [MethodCode]	->	IO [(Int, StackFrame)]
createStackFrames	sccs jclass jmethod codeBlocks= do
	initStackFrame <- initialStackFrame jclass jmethod sccs

	let nullCodeBlocks					= map (\a -> (a, Nothing, False)) (tail codeBlocks)
	let preparedCodeBlocks 			= (head codeBlocks, Just initStackFrame, False) : nullCodeBlocks
	--putStrLn (unlines $ map show preparedCodeBlocks)
	let uninitInferStackFrame 	= inferStackFrame sccs jclass jmethod (offsetToSF preparedCodeBlocks)
	let frameIsAssignable				= uninitFrameIsAssignable sccs
	sf <- stackFramesInference	frameIsAssignable uninitInferStackFrame	preparedCodeBlocks
	return $ zip (map (\(a,b,c) -> fst $ head a) preparedCodeBlocks) sf

--
---
--


differentLastLocalTypes	[]		 []			= 0
differentLastLocalTypes	(x:t1) (y:t2) = if	x==y
	then	differentLastLocalTypes t1 t2
	else 	if 	(x == VTTop) && (1 <= length (x:t1)) && (length (x:t1) <= 3) && (and $ map (== VTTop) t1)
				then length (x:t1)
				else if (y == VTTop) && (1 <= length (y:t2)) && (length (y:t2) <= 3) && (and $ map (== VTTop) t2)
					then negate (length (y:t2))
					else 0

confrontStackFrames	stackFrame1	stackFrame2	delta =
	if (l1 == l2)
		then 	if (s2 == []) 
			then if (delta <= 63)
				then SameFrame 					delta
				else SameFrameExtended 	delta
			else if (length s2 == 1)
				then if (delta <= 63) 
					then SameLocals 				delta ((\[a] -> a) s2)
					else SameLocalsExtended	delta ((\[a] -> a) s2)
				else FullFrame delta (length l2) l2  (length s2) s2
		else 
			let k = differentLastLocalTypes l1 l2 in
				if (s2 == [])
					then if (1 <= k) && (k <= 3)
						then	AppendFrame delta k (drop ((length l2) - k) l2)
						else if (-3 <= k) && (k <= -1)
							then ChopFrame delta (abs k)
							else FullFrame delta (length l2) l2 (length s2) s2
					else FullFrame delta (length l2) l2 (length s2) s2
		where
			SF l1 s1 f1 = stackFrame1
			SF l2 s2 f2 = stackFrame2

createStackMapTable	:: SuperClassSearcher -> JClass -> JMethod -> IO (Maybe [StackMap])
createStackMapTable	sccs jclass jmethod	= do
	-- Divide the method's code in blocks
	let (JM (_,_,_,codeAttribute',_))			= jmethod
	let codeAttribute = case codeAttribute' of 
												Just x -> x
												Nothing -> error "Unexpected empty code attribute"			
	let (MC (methodCode, _,eHandlers,_))	= codeAttribute
	let	exceptionHandlers = case eHandlers of
											Just (ET x)	-> x
											Nothing 		-> []
	let codeBlocks = divideCodeBlocks exceptionHandlers methodCode
	
	-- Calculate the StackFrame of each block
	stackFrames	<- createStackFrames sccs jclass jmethod codeBlocks
	
	-- Infer StackMaps from StackFrames
	if length stackFrames <= 1 
		then return Nothing
		else do
			-- extract the initial frame, since it must be treated differently
			let ((0, initialStackFrame):t) 						= stackFrames
			let ((firstDelta, firstStackFrame):tail)	=	t
			let lineNumberList = (map (\(a, b)->a) tail)

			let deltaTail =	snd $ foldl (\(a, b) lineNumber -> (lineNumber,  b ++ [lineNumber - a - 1])) 	
														(firstDelta, [])
														lineNumberList 
			let deltaList = firstDelta : deltaTail

			let stackFrameList	= map snd t

			let stackMaps = foldl (\(stackMap, b) (delta, nextStackMap)	-> 
															(nextStackMap, b ++ [confrontStackFrames stackMap nextStackMap delta]))
														(initialStackFrame, [])
														(zip deltaList stackFrameList)
			return $ Just (snd stackMaps)
			
			

--XXX:DELETE
--
demo filename = do
	content <- readFile "Test.class"
	let ggg = case runParser classDisassembler "" "" content of {Right x -> snd x; Left s -> error $ show s}
	let prjMC (JM (_,_,_,c,_)) = c
	let prjMN (JC _ _ (JB f m)) = head $ tail m
	let prjCode (MC (x, _,_,_)) = x
	let prjHandlers (MC (_, _, m, _)) = case m of
		Nothing -> []
		Just (ET x)	-> x
		-- hhh == methodCodeAttribute
	let hhh = case (prjMC (prjMN ggg)) of {Just x -> x; Nothing -> error "d'ohhh"}
	let hh =  prjCode hhh
	let h = divideCodeBlocks (prjHandlers hhh) hh
	putStrLn $ concat $ map (\a ->a ++ "\n--------\n") $ map concat $ map (map (\(a,b) -> show a ++ ")\t"++ show b ++  "\n")) h
	env <- getEnvironment (prjCP ggg) "../javaLib/;./"
	sccs <- buildClassHierarchy env
	stack <- initialStackFrame ggg (prjMN ggg) sccs
	putStrLn $ "initial stack: " ++ show stack
	--stacks <- createStackMaps sccs ggg (prjMN ggg) h
	stackMapTable	<-	createStackMapTable	sccs ggg (prjMN ggg)
	return (sccs, stackMapTable)

	{-------------------------------------------------------------------
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -
	 -	 - ---------------------------------------------------------------------}

{---------------
 - ------------
 - ERROR CODES
 - ------------
 ---------------}

showCodeLine (n , code) = show n ++ ": " ++ show code

error_badJTExtraction c= "Jump target extraction failed on line " ++ showCodeLine c ++ "\n."

fail_targetIsUnsafe c target	=	"Target " ++ show target ++ " from " ++ showCodeLine c ++ "is not safe.\n"

fail_invalidTypeTransition vtypes vtype stackFrame codeLine = 
	"Type transition from types " ++ unwords (map show vtypes) 	++ " to type " ++ show (catMaybes [vtype]) ++ "from StackFrame " ++ show	stackFrame	++	" at " ++ showCodeLine codeLine ++ 	" is not safe.\n"

fail_pop	stackFrame typeList codeLine = 
	"Popping types " ++ unwords (map show typeList) ++ "from StackFrame " ++ show stackFrame ++ " failed at " 
	++ showCodeLine codeLine ++ "\n."

fail_localTypeMismatch locals localIndex vtype codeLine = 
	"Type mismatch between local variable type" ++ show localIndex ++ 
	":" ++ show (locals !! localIndex) ++ " and " ++ show vtype ++ " at " ++  showCodeLine codeLine ++ ".\n"

fail_unsafeLoad localIndex vtype stackFrame codeLine = 
	"Unsafe load of type " ++ show vtype ++ " from local variable " ++ show localIndex ++ " in StackFrame " ++ show stackFrame ++ " at " ++ showCodeLine codeLine++ ".\n"

fail_unsafeStore vtype localIndex stackFrame codeLine = 
	"Unsafe store of type " ++ show vtype  ++ " to local variable " ++ show localIndex ++ " in StackFrame " ++ show stackFrame ++ " at " ++ showCodeLine codeLine ++ ".\n"

fail_wrongReturnType	returnType vtype codeLine = "Found wrong return type " ++ show vtype ++ " instead of " ++ show returnType ++ " at " ++ showCodeLine codeLine++ "\n."

fail_assignable t1 t2 codeLine = "Cannot assign type " ++ show t1 ++ " to type " ++ show t2 ++ " at " ++ showCodeLine codeLine ++ ".\n" 
----------------------------------------------------------------------------------------

extractInvokeMethodInfo cp i = case entryAtIndex i cp of
	MR classIndex methodIndex	-> case entryAtIndex classIndex cp of
		C	classNameIndex -> case entryAtIndex classNameIndex cp of
			MUtf8	className	-> case entryAtIndex methodIndex cp of
				NT methodNameIndex methodSigIndex	-> case entryAtIndex methodNameIndex cp of
					MUtf8	methodName	->	case entryAtIndex methodSigIndex cp of
						MUtf8	signature	->	case runParser methodSignature "" "" signature of
								Right	(args, ret)	->	return (className, classIndex, methodName, args, ret)
								Left failed	->	fail $ "Signature parsing from entry "++ show i ++" failed: " ++ show failed	++".\n"
						x	->	fail $"Expection string, found "	++ show x ++ " at index " ++ show i ++ " of the constant pool.\n"
					x	->	fail $"Expection string, found "	++ show x ++ " at index " ++ show i ++ " of the constant pool.\n"
				x	-> fail $"Expection Method Reference, found " ++ show x ++ " at index " ++ show i ++ " of the constant pool.\n"
			x	->	fail $"Expection string, found "	++ show x ++ " at index " ++ show i ++ " of the constant pool.\n"
		x	->	fail $"Expection Class, found "	++ show x ++ " at index " ++ show i ++ " of the constant pool.\n"
	x	-> fail $"Expection Method Reference, found " ++ show x ++ " at index " ++ show i ++ " of the constant pool.\n"

{------------------------
 - ---------------------
 - TYPING RULE PATTERNS
 - ---------------------
 ------------------------}
uninitValidTypeTransition_pattern validTypeTransition stackFrame codeLine exceptionStackFrame accList popTypes pushType = do
	maybeNextStack	<- validTypeTransition popTypes pushType stackFrame
	case maybeNextStack of
				Just nextStack	->	return (Just nextStack, Just $ exceptionStackFrame nextStack, accList)
				Nothing					->	fail $ fail_invalidTypeTransition popTypes pushType stackFrame codeLine


---
--
---

uninitPop_pattern pop accList codeLine stackFrame poppedTypes = do
	maybeNextStackFrame <- pop stackFrame poppedTypes
	case maybeNextStackFrame	of
		Just nextStackFrame	-> return (Just nextStackFrame, Just $ exceptionStackFrame nextStackFrame, accList)
		Nothing							-> fail $ fail_pop	stackFrame poppedTypes codeLine


uninitPop_target_pattern pop targetIsSafe exceptionStackFrame accList codeLine stackFrame	poppedTypes =	do
			let [target]	= case extractJumpTarget codeLine of
										Just t	->	t
										Nothing	->	error $ error_badJTExtraction codeLine
			maybeNextStack	<- 	pop stackFrame poppedTypes 
			case maybeNextStack of
				Just nextStackFrame	->	do
					safe		<- targetIsSafe	nextStackFrame	target 
					if safe
						then do
							let accEntry	=	(target, nextStackFrame)
							return (Just nextStackFrame,  Just $ exceptionStackFrame nextStackFrame, accEntry : accList)
						else fail $ fail_targetIsUnsafe codeLine target
				Nothing					->	fail $ fail_pop	stackFrame poppedTypes codeLine


---
--
---

uninitLoadIsTypeSafe_pattern	loadIsTypeSafe jmethod stackFrame accList exceptionStackFrame codeLine localIndex vtype = do
	maybeNextFrame <- loadIsTypeSafe jmethod localIndex (Just vtype) stackFrame
	case maybeNextFrame of
		Just nextFrame	->	return (Just nextFrame, Just $ exceptionStackFrame nextFrame, accList)
		Nothing					->	fail $ fail_unsafeLoad localIndex VTInteger stackFrame codeLine

uninitStoreIsTypeSafe_pattern storeIsTypeSafe stackFrame accList exceptionStackFrame codeLine index vtype = do
	maybeNextFrame	<- storeIsTypeSafe index vtype stackFrame
	case maybeNextFrame of
		Just nextFrame	->	return (Just nextFrame, Just $ exceptionStackFrame nextFrame, accList)
		Nothing					->	fail $ fail_unsafeStore vtype index stackFrame codeLine 

--
---
--
uninitReturn_pattern jmethod pop stackFrame accList codeLine jtype = do
			let (JM (_, (MT (_,returnType), _), _, _, _)) = jmethod
			case returnType of
				MRT jtype	->	do
					maybeNextStackFrame	<- pop stackFrame [jtypeToVtype jtype] 
					case maybeNextStackFrame of
						Just x	->	return (Nothing, Nothing, accList)
						Nothing	->	fail $ fail_pop stackFrame [VTInteger] codeLine
				_							->	fail $ fail_wrongReturnType	returnType VTInteger codeLine

--
---
--


inferStackFrame	::	SuperClassSearcher	-> JClass	->	JMethod	->	(Int -> Maybe StackFrame)	->
										(Maybe StackFrame, Maybe StackFrame, [(Int, StackFrame)]) -> CodeLine	->
										IO (Maybe StackFrame, Maybe StackFrame, [(Int, StackFrame)])
inferStackFrame	sccs jclass	jmethod	offsetToStackFrame accumulator	codeLine	= do
	-- prepare StackFrame operators
	let validTypeTransition 	= uninitValidTypeTransition		sccs jmethod;
			popMatchingType 			= uninitPopMatchingType				sccs;
	 		popMatchingList 	 		= uninitPopMatchingList				sccs;
			popCategory1 					= uninitPopCategory1					sccs;
			popCategory2 					= uninitPopCategory2					sccs;
			pop 									= uninitPop										sccs;
			pushOperandStack	 		= uninitPushOperandStack			sccs;
			safelyPush 						= uninitSafelyPush						sccs;
			safelyPushList 				= uninitSafelyPushList				sccs;
			pushList 							= uninitPushList							sccs;
			modifyLocalVariable		= uninitModifyLocalVariable		sccs;
			loadIsTypeSafe 				= uninitLoadIsTypeSafe				sccs;
			storeIsTypeSafe 			= uninitStoreIsTypeSafe				sccs;
			targetIsTypeSafe			= uninitTargetIsTypeSafe			sccs offsetToStackFrame;
			isAssignable					= uninitIsAssignable					sccs;

	-- project some needed information from the class or the method
	let cp = prjCP jclass;
			repeatInferStackFrame	=	inferStackFrame sccs jclass jmethod offsetToStackFrame accumulator;
			(lineNumber, instruction) = codeLine;
			(JM (methodName, (methodType, _), _, Just (MC (methodCode, _,_,_)), _)) = jmethod	;
			
{-	a	<- case accumulator of
			(Nothing, _, _ )	-> putStrLn $ "DEBUG: No accumulator at " ++ showCodeLine codeLine ++ "\n."
			_	-> putStr "ok "-}
	
	--1: previous stackFrame
	--2: exception stackFrame: this must be set by this function
	--3: list of stackFrame for blocks in the code
	let (Just stackFrame, _, accList)	= accumulator;
			(SF locals stack flags) 			= stackFrame;

--	putStrLn $ "DEBUG: inferFS: inputs: " ++ showCodeLine codeLine  ++"; stackFrame = " ++ show stackFrame

	--Patterns.
	--Type checking rules for different instructions actually follow
	--a minor number of checking patterns, which are synthetized in the 
	--followin terms.
	let validTypeTransition_pattern = uninitValidTypeTransition_pattern validTypeTransition stackFrame codeLine 
																																			exceptionStackFrame accList;
			pop_pattern 					 = uninitPop_pattern pop accList codeLine stackFrame;
			pop_target_pattern	   = uninitPop_target_pattern pop targetIsTypeSafe exceptionStackFrame accList codeLine 
																												stackFrame;
			loadIsTypeSafe_pattern = uninitLoadIsTypeSafe_pattern	loadIsTypeSafe jmethod stackFrame accList 
																														exceptionStackFrame codeLine;
			storeIsTypeSafe_pattern = uninitStoreIsTypeSafe_pattern storeIsTypeSafe stackFrame accList 
																															exceptionStackFrame codeLine;
			return_pattern = uninitReturn_pattern jmethod pop stackFrame accList codeLine;

{--------------
 - -----------
 - TYPE RULES
 - -----------
 --------------}

	case instruction of
		AALoad 			-> do
			let arrayType 		= stack !! 3;
					componentType = case arrayType of
											VTArray a	-> a
											c					-> error $ "Unexpected type " ++ show c ++ " at " ++ showCodeLine codeLine ++ ".\n"
			validTypeTransition_pattern [VTInteger, VTArray (VTClass _JAVA_LANG_OBJECT)] (Just componentType)
								
		AAStore 		-> pop_pattern [VTClass _JAVA_LANG_OBJECT, VTInteger, VTArray (VTClass _JAVA_LANG_OBJECT)]
		AConst_Null -> validTypeTransition_pattern [] Nothing
		ALoad localIndex 	-> loadIsTypeSafe_pattern localIndex VTReference
		ALoad_0 					-> loadIsTypeSafe_pattern 0 VTReference
		ALoad_1 					-> loadIsTypeSafe_pattern 1 VTReference
		ALoad_2 					-> loadIsTypeSafe_pattern 2 VTReference
		ALoad_3 					-> loadIsTypeSafe_pattern 3 VTReference
		ANewArray cpIndex	-> 	case entryAtIndex cpIndex cp of
			C classIndex	->	case entryAtIndex	classIndex cp of
				MUtf8	className	->	validTypeTransition_pattern [VTInteger] (Just $ VTClass className)
				_								->	error "Expecting class name.\n"
			MUtf8	string	->	validTypeTransition_pattern [VTInteger] (Just $ stringToVTArray string)
				where
					stringToVTArray ('[':t) =	VTArray (stringToVTArray t)
					stringToVTArray	('L':t)	=	VTClass (take (length t - 1) t)	
					stringToVTArray	_				=	error "Expecting class or array index.\n"

			_							-> fail "Expecting class or array index.\n"
				
								
		AReturn -> do
			returnType <- case methodType of
						IgnoredMT	s		->	fail $ "Error: ignored signature"  ++ s
						MT (_, Void)	->	fail $ "Type inference failed. Cannot assign Void to Reference at " ++ showCodeLine codeLine
						MT (_, MRT t)	->	return $ jtypeToVtype t
			assignable <- isAssignable returnType VTReference
			if assignable 
				then do
					poppedFrame <- pop stackFrame [returnType]
					case poppedFrame of
						Just _	->	return (Just stackFrame, Just $ exceptionStackFrame stackFrame, accList)
						Nothing	->	fail $ fail_pop stackFrame [returnType] codeLine
				else fail $ fail_assignable returnType VTReference codeLine

		ArrayLength -> do
			let arrayType 		= stack !! 2;
					componentType = case arrayType of
											VTArray a	-> a
											c					-> error $ "Unexpected type " ++ show c ++ " at " ++ showCodeLine codeLine ++ ".\n"
			validTypeTransition_pattern [VTTop] (Just VTInteger)

		AStore localIndex -> storeIsTypeSafe_pattern localIndex VTReference 
		AStore_0 -> storeIsTypeSafe_pattern 0 VTReference 
		AStore_1 -> storeIsTypeSafe_pattern 1 VTReference 
		AStore_2 -> storeIsTypeSafe_pattern 2 VTReference 
		AStore_3 -> storeIsTypeSafe_pattern 3 VTReference 
		AThrow	->	pop_pattern	[VTClass "java/lang/Throwable"] 
{-		BALoad	-> 
		BAStore	-> 
		BiPush Int -> 
		CALoad	-> 
		CAStore -> 
		CheckCast CPIndex ->-} 
		D2F	-> validTypeTransition_pattern [VTDouble] (Just VTFloat)
		D2I -> validTypeTransition_pattern [VTDouble] (Just VTInteger)
		D2L -> validTypeTransition_pattern [VTDouble] (Just VTLong)
		DAdd -> validTypeTransition_pattern [VTDouble, VTDouble] (Just VTDouble)
{-		DALoad -> 
		DAStore -> -}
		DCMPG -> validTypeTransition_pattern [VTDouble] (Just VTFloat)
		DCMPL -> validTypeTransition_pattern [VTDouble,VTDouble] (Just VTInteger)
		DConst_0 -> validTypeTransition_pattern [] (Just VTDouble)
		DConst_1 -> validTypeTransition_pattern [] (Just VTDouble)
		DDiv -> validTypeTransition_pattern [VTDouble, VTDouble] (Just VTDouble)
		DLoad localIndex -> loadIsTypeSafe_pattern  localIndex VTDouble
		DLoad_0 -> loadIsTypeSafe_pattern  0 VTDouble
		DLoad_1 -> loadIsTypeSafe_pattern  1 VTDouble
		DLoad_2 -> loadIsTypeSafe_pattern  2 VTDouble
		DLoad_3 -> loadIsTypeSafe_pattern  3 VTDouble
		DMul -> validTypeTransition_pattern [VTDouble, VTDouble] (Just VTDouble)
		DNeg -> validTypeTransition_pattern [VTDouble] (Just VTDouble)
		DRem -> validTypeTransition_pattern [VTDouble, VTDouble] (Just VTDouble)
		DReturn -> do
			dret <- pop_pattern [VTDouble]
			return (Just stackFrame, Just $ exceptionStackFrame stackFrame, accList)
		DStore localIndex -> storeIsTypeSafe_pattern localIndex VTDouble
		DStore_0 -> storeIsTypeSafe_pattern 0 VTDouble
		DStore_1 -> storeIsTypeSafe_pattern 1 VTDouble
		DStore_2 -> storeIsTypeSafe_pattern 2 VTDouble
		DStore_3 -> storeIsTypeSafe_pattern 3 VTDouble
		DSub -> validTypeTransition_pattern [VTDouble, VTDouble] (Just VTDouble)
--
---
--

		Dup -> do
			poppedStack <- popCategory1 stack Nothing
			case poppedStack of
				Just (_poppedstack, dupVType)	->	do
					nextStack  <-  pushOperandStack stack (Just dupVType)
					let nextStackFrame = SF locals nextStack flags
					return (Just nextStackFrame, Just $ exceptionStackFrame stackFrame, accList)
				Nothing	->	fail $ "The top element of the stack in StackFrame " ++ show stackFrame ++ " is not of category 1 at " ++ showCodeLine codeLine

{-		Dup_x1 -> 
		Dup_x2 -> 
		Dup2 -> 
		Dup2_x1 -> 
		Dup2_x2 -> -}
		F2D -> validTypeTransition_pattern [VTFloat] (Just VTDouble)
		F2I -> validTypeTransition_pattern [VTFloat] (Just VTInteger)
		F2L -> validTypeTransition_pattern [VTFloat] (Just VTLong)
		FAdd -> validTypeTransition_pattern [VTFloat, VTFloat] (Just VTFloat)
{-		FALoad -> 
		FAStore -> -}
		FCMPG -> validTypeTransition_pattern [VTFloat, VTFloat] (Just VTInteger)
		FCMPL -> validTypeTransition_pattern [VTFloat, VTFloat] (Just VTInteger)
		FConst_0 -> validTypeTransition_pattern [] (Just VTFloat)
		FConst_1 -> validTypeTransition_pattern [] (Just VTFloat)
		FConst_2 -> validTypeTransition_pattern [] (Just VTFloat)
		FConst_3 -> validTypeTransition_pattern [] (Just VTFloat) --XXX:DOES IT EXISTS?????
		FDiv -> validTypeTransition_pattern [VTFloat, VTFloat] (Just VTFloat)
		FLoad localIndex -> loadIsTypeSafe_pattern  localIndex VTFloat 
		FLoad_0 -> loadIsTypeSafe_pattern  0 VTFloat
		FLoad_1 -> loadIsTypeSafe_pattern  1 VTFloat
		FLoad_2 -> loadIsTypeSafe_pattern  2 VTFloat
		FLoad_3 -> loadIsTypeSafe_pattern  3 VTFloat
		FMul -> validTypeTransition_pattern [VTFloat, VTFloat] (Just VTFloat)
		FNeg -> validTypeTransition_pattern [VTFloat] (Just VTFloat)
		FRem -> validTypeTransition_pattern [VTFloat, VTFloat] (Just VTFloat)
		FReturn -> return_pattern Jfloat
		FStore localIndex -> storeIsTypeSafe_pattern localIndex VTFloat
		FStore_0 -> storeIsTypeSafe_pattern 0 VTFloat
		FStore_1 -> storeIsTypeSafe_pattern 1 VTFloat
		FStore_2 -> storeIsTypeSafe_pattern 2 VTFloat
		FStore_3 -> storeIsTypeSafe_pattern 3 VTFloat
		FSub -> validTypeTransition_pattern [VTFloat, VTFloat] (Just VTFloat)
		
		GetField cpIndex -> do
			fieldInfo <- case entryAtIndex cpIndex cp of
				FR	classIndex natIndex	->	case entryAtIndex classIndex cp of
					C sIndex ->	case entryAtIndex sIndex cp of
						MUtf8 className	->	case entryAtIndex natIndex cp of
							NT nameIndex descrIndex 	-> case entryAtIndex nameIndex cp of
								MUtf8 fieldName	->	case entryAtIndex descrIndex cp of
									MUtf8 fieldDescriptor	-> return (className, fieldName, fieldDescriptor)
									_	-> fail "Field descriptor not found.\n"
								_	-> fail "Field name not found.\n"
							_	->	fail "NameAndType not found.\n"
						_	-> fail "Class name not found.\n"
					_	-> fail "Class entry not found.\n"
				_	->	fail "Field reference not found.\n"
			let (fClass, fName, fDescriptor) = fieldInfo
			let fType = jtypeToVtype $ fieldSignature fDescriptor
			validTypeTransition_pattern [VTClass fClass] (Just fType)	

--		GetStatic CPIndex -> 
		
		Goto 	i	-> do	
								let [target]	= case extractJumpTarget codeLine of
										Just t	->	t
										Nothing	->	error $ error_badJTExtraction codeLine
								safe		<- targetIsTypeSafe	stackFrame	target 
								if safe
									then do
										let accEntry	=	(target, stackFrame)
										return (Just stackFrame,  Just $ exceptionStackFrame stackFrame,  accEntry : accList)
									else fail $ fail_targetIsUnsafe codeLine target

		GotoW i	-> do
			r	<-	repeatInferStackFrame	(lineNumber, Goto i)
			return r

		I2B -> validTypeTransition_pattern [VTInteger] (Just VTInteger) 
		I2C -> validTypeTransition_pattern [VTInteger] (Just VTInteger)
		I2D -> validTypeTransition_pattern [VTInteger] (Just VTDouble)
		I2F -> validTypeTransition_pattern [VTInteger] (Just VTFloat)
		I2L -> validTypeTransition_pattern [VTInteger] (Just VTLong)
		I2S -> validTypeTransition_pattern [VTInteger] (Just VTInteger)
		IAdd -> validTypeTransition_pattern [VTInteger, VTInteger] (Just VTInteger)
--		IALoad -> 
		IAnd -> validTypeTransition_pattern [VTInteger, VTInteger] (Just VTInteger)
--		IAStore -> 

--

		IConst_0 -> validTypeTransition_pattern [] (Just VTInteger)
		IConst_m1 ->validTypeTransition_pattern [] (Just VTInteger)
		IConst_1 ->	validTypeTransition_pattern [] (Just VTInteger)		
		IConst_2 ->	validTypeTransition_pattern [] (Just VTInteger)
		IConst_3 ->	validTypeTransition_pattern [] (Just VTInteger)
		IConst_4 ->	validTypeTransition_pattern [] (Just VTInteger)
		IConst_5 ->	validTypeTransition_pattern [] (Just VTInteger)

--

		IDiv -> validTypeTransition_pattern [VTInteger, VTInteger] (Just VTInteger)

--

		IFACMPEQ i -> pop_target_pattern [VTReference, VTReference]
		IFACMPNE i -> pop_target_pattern [VTReference, VTReference]

--
		
		IFICMPEG i 	-> pop_target_pattern [VTInteger, VTInteger]
		IFCMPNE	 i	-> pop_target_pattern [VTInteger, VTInteger]
		IFICMPLT i	-> pop_target_pattern [VTInteger, VTInteger]
		IFICMPGE i	-> pop_target_pattern [VTInteger, VTInteger]
		IFICMPGT i	-> pop_target_pattern [VTInteger, VTInteger]
		IFICMPLE i	-> pop_target_pattern [VTInteger, VTInteger]

--
		
		IfEQ i ->	pop_target_pattern [VTInteger] 
		IfNE i -> pop_target_pattern [VTInteger]
		IfLT i -> pop_target_pattern [VTInteger]
		IfGE i -> pop_target_pattern [VTInteger]
		IfGT i -> pop_target_pattern [VTInteger]
		IfLE i -> pop_target_pattern [VTInteger]

--
		
		IfNonNull i -> pop_target_pattern [VTReference] 
		IfNull i 		-> pop_target_pattern [VTReference] 
	
--

		IInc localIndex i ->	if	(locals !! localIndex) == VTInteger
			then return (Just stackFrame, Just $ exceptionStackFrame stackFrame, accList)
			else fail $ fail_localTypeMismatch locals localIndex VTInteger codeLine
		
--

		ILoad localIndex -> loadIsTypeSafe_pattern localIndex VTInteger
		ILoad_0 -> loadIsTypeSafe_pattern 0 VTInteger
		ILoad_1 -> loadIsTypeSafe_pattern 1 VTInteger
		ILoad_2 -> loadIsTypeSafe_pattern 2 VTInteger
		ILoad_3 -> loadIsTypeSafe_pattern 3 VTInteger

		IMul -> validTypeTransition_pattern [VTInteger, VTInteger] (Just VTInteger)
		INeg -> validTypeTransition_pattern [VTInteger] (Just VTInteger)
{-		InstanceOf CPIndex -> 
		InvokeInterface CPIndex Int -> --Int = count-}
		InvokeSpecial 	cpIndex ->	case methodName of
				"<clinit>"	->	fail $ "Type inference failed.\nCannot instantiate <clinit> using InvokeSpecial.\n"
				"<init>"		->	do
					(mClassName, mClassIndex, mName, mArgs, mRet) <- extractInvokeMethodInfo cp cpIndex
					if (mRet /= Void)
						then fail $ "Type inference failed.\nCannot initizialize non-void constructor.\n"
						else do
							let stackArgList = reverse $ map jtypeToVtype mArgs
							maybeTempStackFrame <- pop stackFrame stackArgList
							when (maybeTempStackFrame == Nothing) (fail $ fail_pop stackFrame stackArgList codeLine)
							let Just (SF tempLocals tempStack tempFlags) = maybeTempStackFrame
							let uninitArg = head tempStack 
							let initArg = case uninitArg of
										VTUninitializedThis					 -> VTClass (prjClassName jclass)
										VTUninitializedOffset offset -> case snd $ methodCode !! offset of
																											New i		->	if i == mClassIndex
																												then	VTClass mClassName
																												else error $ "Type inference failed. New " ++ 
																																			show mClassIndex ++
																																			" not found-\n"
										_														 -> error $ "Expecting uninitialized reference.\n"
							let nextLocals 	= map (\a -> if a == uninitArg then initArg else a)	tempLocals
							let nextStack 	= map (\a -> if a == uninitArg then initArg else a)	tempStack
							let nextFlags		= case uninitArg of
												VTUninitializedThis			->	[]
												VTUninitializedOffset o	->	tempFlags
							let nextStackFrame = SF nextLocals nextStack nextFlags
							return (Just nextStackFrame, Just $ exceptionStackFrame nextStackFrame, accList)

				s	->	do
					(mClassName, mClassIndex, mName, mArgs, mRet) <-  extractInvokeMethodInfo cp cpIndex
					let retType = case mRet of
						Void	-> Nothing
						MRT t	-> Just (jtypeToVtype t)
					let stackArgList1 = reverse $ (VTClass $ prjClassName jclass):(map jtypeToVtype mArgs)
					let stackArgList2 = reverse $ (VTClass mClassName):(map jtypeToVtype mArgs)
					
					nextStackFrames1	<-	validTypeTransition_pattern	stackArgList1 retType 
					nextStackFrames2	<-	validTypeTransition_pattern	stackArgList2 retType 
					
					assignable <- isAssignable (VTClass $ prjClassName jclass) (VTClass mClassName)
					if assignable
						then return nextStackFrames1
						else fail $ "Type inference failed. StackFrame mismatch during invokespecial at " ++ showCodeLine codeLine ++ ".\n" 


--		InvokeStatic  	CPIndex -> 
		InvokeVirtual cpIndex	-> do
			(mClassName, mClassIndex, mName, mArgs, mRet) <- extractInvokeMethodInfo cp cpIndex
			if mName /= "<init>" && mName /= "<clinit>"
				then do
					let argList = map jtypeToVtype mArgs
					let stackArgList = reverse $ (VTClass mClassName) : (reverse argList)
					let returnType = case mRet of
										Void				->	Nothing
										MRT retType	->	Just $ jtypeToVtype retType
					nextStackFrame <- validTypeTransition_pattern stackArgList returnType
					poppedStackFrame	<-	pop_pattern argList
					return nextStackFrame
				else fail $ "Cannot invoke " ++ mName ++ "with InvokeVirtual " ++ " at " ++ showCodeLine codeLine
			
--

		IOr  -> validTypeTransition_pattern [VTInteger, VTInteger] (Just VTInteger)
		IRem -> validTypeTransition_pattern [VTInteger, VTInteger] (Just VTInteger)

--
		IReturn ->	do
			let (JM (_, (MT (_,returnType), _), _, _, _)) = jmethod
			case returnType of
				MRT Jint	->	do
					maybeNextStackFrame	<- pop stackFrame [VTInteger] 
					case maybeNextStackFrame of
						Just x	->	return (Nothing, Nothing, accList)
						Nothing	->	fail $ fail_pop stackFrame [VTInteger] codeLine
				_							->	fail $ fail_wrongReturnType	returnType VTInteger codeLine

--

		IShl -> validTypeTransition_pattern [VTInteger, VTInteger] (Just VTInteger)
		IShr -> validTypeTransition_pattern [VTInteger, VTInteger] (Just VTInteger)

--

		IStore localIndex -> storeIsTypeSafe_pattern localIndex VTInteger
		IStore_0 -> storeIsTypeSafe_pattern 0 VTInteger
		IStore_1 -> storeIsTypeSafe_pattern 1 VTInteger
		IStore_2 -> storeIsTypeSafe_pattern 2 VTInteger
		IStore_3 -> storeIsTypeSafe_pattern 3 VTInteger

--

		ISub -> validTypeTransition_pattern [VTInteger, VTInteger] (Just VTInteger)
		IUShr -> validTypeTransition_pattern [VTInteger, VTInteger] (Just VTInteger)
		IXor -> validTypeTransition_pattern [VTInteger, VTInteger] (Just VTInteger)
		{-
		JSR Offset -> 
		JSR_W Offset ->-} 
		L2D -> validTypeTransition_pattern [VTLong] (Just VTDouble)
		L2F -> validTypeTransition_pattern [VTLong] (Just VTFloat)
		L2I -> validTypeTransition_pattern [VTLong] (Just VTInteger)
		LAdd -> validTypeTransition_pattern [VTLong, VTLong] (Just VTLong)
{-		LALoad -> -}
		LAnd -> validTypeTransition_pattern [VTLong, VTLong] (Just VTLong)
{-		LAStore -> -}
		LCmp -> validTypeTransition_pattern [VTLong, VTLong] (Just VTInteger)
		LConst_0 -> validTypeTransition_pattern [] (Just VTLong)
		LConst_1 -> validTypeTransition_pattern [] (Just VTLong)
{-		LDC RCPIndex -> 
		LDC_W RCPIndex -> 
		LDC2_W RCPIndex -> -}
		LDiv -> validTypeTransition_pattern [VTLong, VTLong] (Just VTLong)
		LLoad localIndex -> loadIsTypeSafe_pattern localIndex VTLong
		LLoad_0 -> loadIsTypeSafe_pattern 0 VTLong
		LLoad_1 -> loadIsTypeSafe_pattern 1 VTLong
		LLoad_2 -> loadIsTypeSafe_pattern 2 VTLong
		LLoad_3 -> loadIsTypeSafe_pattern 3 VTLong
		LMul  -> validTypeTransition_pattern [VTLong, VTLong] (Just VTLong)
		LNeg -> validTypeTransition_pattern [VTLong] (Just VTLong)
{-		LookUpSwitch Integer Integer [(Integer, Integer)] -> -}
		LOr -> validTypeTransition_pattern [VTLong, VTLong] (Just VTLong)
		LRem -> validTypeTransition_pattern [VTLong, VTLong] (Just VTLong)
		LReturn -> return_pattern Jlong 
		LShl -> validTypeTransition_pattern [VTInteger, VTLong] (Just VTLong)
		LShr -> validTypeTransition_pattern [VTInteger, VTLong] (Just VTLong)
		LStore localIndex -> storeIsTypeSafe_pattern localIndex VTLong
		LStore_0 -> storeIsTypeSafe_pattern 0 VTLong
		LStore_1 -> storeIsTypeSafe_pattern 1 VTLong
		LStore_2 -> storeIsTypeSafe_pattern 2 VTLong
		LStore_3 -> storeIsTypeSafe_pattern 3 VTLong
		LSub -> validTypeTransition_pattern [VTLong, VTLong] (Just VTLong)
		LUShr -> validTypeTransition_pattern [VTInteger, VTLong] (Just VTLong)
		LXor -> validTypeTransition_pattern [VTLong, VTLong] (Just VTLong)

--

		MonitorEnter ->	pop_pattern [VTReference]
		MonitorExit ->	pop_pattern [VTReference]

--
		
--		MultiANewArray RCPIndex Int	->

		New cpIndex -> do
			let isClass = case entryAtIndex cpIndex cp of
					C	_	->	True
					_		->	False
			if isClass 
				then do
					let newItem = VTUninitializedOffset lineNumber
					if not (elem newItem stack)
						then	do
							let nextLocals  = map (\a -> if a == newItem then VTTop else a) locals
							let nextStackFrame = SF nextLocals stack flags
							uninitValidTypeTransition_pattern validTypeTransition nextStackFrame codeLine exceptionStackFrame accList	[] (Just newItem)	
						else fail $ "Uninitialized object already present on the stack.\n"
				else fail $ "Cannot instantiate New instruction with a non-class entry.\n"
			

--		NewArray JType -> 
	
		NOp -> return (Just stackFrame, Just $ exceptionStackFrame stackFrame, accList)

{-		Pop -> 
		Pop2 ->-} 
		PutField	cpIndex -> do
			fieldInfo <- case entryAtIndex cpIndex cp of
				FR	classIndex natIndex	->	case entryAtIndex classIndex cp of
					C sIndex ->	case entryAtIndex sIndex cp of
						MUtf8 className	->	case entryAtIndex natIndex cp of
							NT nameIndex descrIndex 	-> case entryAtIndex nameIndex cp of
								MUtf8 fieldName	->	case entryAtIndex descrIndex cp of
									MUtf8 fieldDescriptor	-> return (className, fieldName, fieldDescriptor)
									_	-> fail "Field descriptor not found.\n"
								_	-> fail "Field name not found.\n"
							_	->	fail "NameAndType not found.\n"
						_	-> fail "Class name not found.\n"
					_	-> fail "Class entry not found.\n"
				_	->	fail "Field reference not found.\n"
			let (fClass, fName, fDescriptor) = fieldInfo
			let fType = jtypeToVtype $ fieldSignature fDescriptor

			(Just tempStackFrame, _, _) <- pop_pattern [fType]
			uninitPop_pattern pop accList codeLine tempStackFrame [VTClass fClass]

--	PutStatic RCPIndex -> 
--	Ret LocalIndex -> -}
		Return -> do
			case methodType of
				MT (x, Void)	->	if elem FlagThisUninit flags
					then	error	$ "Type inference failed.\n Object uninitialized while exiting method " ++ methodName ++ 
												" at " ++ showCodeLine codeLine	++	".\n"
					else	return (Nothing, Just $ exceptionStackFrame stackFrame, accList)
				MT (x, MRT s)	->	error $ "Type inference failed.\nExpecting void, found " ++ show s ++ " at " ++ 
																	showCodeLine codeLine ++ " in method " ++ methodName ++ ".\n"
				IgnoredMT s	->	error $ "Type inference failed.\nFound ignored method type " ++ s ++ 
																" in method " ++ methodName ++ " at " ++ showCodeLine codeLine ++".\n"
{-		SALoad -> 
		SAStore -> -}
		
		SiPush i ->  validTypeTransition_pattern [] (Just VTInteger)

{-		Swap -> 
		TableSwitch Integer Integer Integer [Integer] -> 
		Wide_Format1 JInstruction Int	-> 
		Wide_Format2 Int Int	->
		-}
