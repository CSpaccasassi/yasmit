class Test {
  int runIt(int i) {
			int j;
	    //if (i==0) {j = zeroTest(2); 
			//}
			j = 0;
			boolean bool = false;
			while (bool == false){
					if (j < 5) j++;
						else bool = true;
			}
			if (j == 0) return j;
				else return 666;
	}
	int zeroTest(int i) { 
		if (1==2){ useless(); return 1;}
			else return 0;
	}
	void useless(){}
}
