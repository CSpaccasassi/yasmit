module JClassData where

import Data.Int
import Data.Array
import Data.Tree

data JClass = JC JMetadata ConstantPool JBody 	-- Class
				    | JI JMetadata ConstantPool JBody 	-- Interface -- XXX: remove it?


{---------------------------------------
 - Java Types:
 - B    byte            signed byte
 - C    char            Unicode character
 - D    double          double-precision floating-point value
 - F    float           single-precision floating-point value
 - I    int             integer
 - J    long            long integer
 - L		reference 			an instance of class <classname>
 - S    short           signed short
 - Z    boolean         true or false
 - [    reference       one array dimension 
 - --------------------------------------}

data JType								= Jbyte | Jchar | Jdouble | Jfloat 
													| Jint  | Jlong | Jbool   | Jshort 
													| Jclass String | Jarray JType
													deriving (Eq, Show)

-- Access flags.
data ClassAccessFlag      = PublicC			| FinalC 		| SuperC			| InterfaceC
													| AbstractC   | PackageC	| SyntheticC	|	AnnotationC
													|	EnumC
												  deriving (Eq, Show)

data InnerClassAccessFlag	= PublicIC		| PrivateIC 	| ProtectedIC	| FinalIC  
											  	| AbstractIC	| StaticIC 		| PackageIC
												  deriving (Eq, Show)

data FieldAccessFlag 	  	= PublicF  | PrivateF  | ProtectedF  | FinalF   
												  | StaticF  | VolatileF | TransientF  | PackageF
													| EnumF		 | SyntheticF
												  deriving (Eq, Show)

data MethodAccessFlag	  	= PublicM  | PrivateM  | ProtectedM  | FinalM   
			  									| StaticM  | NativeM   | AbstractM   | SynchronizedM		
												  | StrictM  | PackageM  | BridgeM     | VarArgsM
													| SyntheticM
													deriving (Eq, Show)

{---------------------------------------
 - Attributes of a class.
 - NOTE: InnerClasses contains in order: 
 - 1) a list of its access flags 
 - 2) an index to a string, its name, 
 - 3) an index to its own class
 - 4) an index to its outer class
 ---------------------------------------}
data ClassAttribute = InnerClasses [([InnerClassAccessFlag], CPIndex, CPIndex, CPIndex)]
		    | DeprecatedCA 
		    | SyntheticCA 
		    | SourceFile String 
				deriving (Eq, Show)

-- Metadata
data ClassVersion     = CV (Int, Int)    			-- Major and minor number
												deriving (Eq, Show)
data ClassInterfaces  = CI [CPIndex] 					--XXX: metti string name
												deriving (Eq, Show)
data ClassAttributes  = CA [ClassAccessFlag]
												deriving (Eq, Show)
data ClassParent      = CP String			 				-- Note that Object has no parent
												deriving (Eq, Show)
data ClassName        = CN String
												deriving (Eq, Show)

data JMetadata = JMeta (ClassName, ClassAttributes, Maybe ClassParent, ClassInterfaces, ClassVersion, [ClassAttribute])

-- Constant Pool entries
data CPEntry 	=	MUtf8 String				-- Asciz: null-terminated string
	 						|	S  	CPIndex					-- Java String										: utf8Index
							|	NT 	CPIndex CPIndex	-- Name and Type									: utf8Index		utf8Index
				   		|	C  	CPIndex 				-- Class or Interface Identifier	:	utf8Index
				  	  |	MR	CPIndex CPIndex	-- Method Reference								: classIndex	nameAndTypeIndex
							|	IMR	CPIndex CPIndex	-- Interface Method Reference 		:	classIndex	nameAndTypeIndex
					    |	FR	CPIndex CPIndex	-- Field Reference								:	classIndex	nameAndTypeIndex
					    |	I  	Int32						-- Java 32 bit integer
					    |	L  	Int64						-- Java 64 bit long integer
					    |	F  	Float						-- XXX:Floating Point Support?
					    |	D  	Double					-- XXX: Floating Point Support?
							|	Unusable						-- Unusable entry, used after a Long or Double entry
							deriving (Eq, Show)
-- Index of a constant pool entry.
type CPIndex = Int

-- The Constant Pool of a .class file is an array of CPEntries indexed by an Int
type ConstantPool = Array Int CPEntry

-- Body Definitions XXX CHANGE DESCRIPTION
data JDescriptor = JFD FieldType 
		 						 | JMD MethodType
								 deriving (Eq, Show)
-- Java Field definition
data FieldAttribute	= CFV CPIndex 
										| SyntheticFA 
										| DeprecatedFA 
										| FS JType	
										| UnknownFA String
										deriving (Eq, Show)

type FieldName 		= String
type FieldType		= JType

data JField 		= JF (FieldName, FieldType, [FieldAccessFlag], [FieldAttribute])
									deriving (Eq, Show)

-- Java Method definition
type LocalIndex = Int
type Offset			= Int
type RCPIndex		= Int -- Runtime Constant Pool Index
data JInstruction = AALoad 	| AAStore | AConst_Null | ALoad LocalIndex 
									| ALoad_0 | ALoad_1 | ALoad_2 | ALoad_3 | ANewArray CPIndex
									| AReturn | ArrayLength 			| AStore LocalIndex 
									| AStore_0 | AStore_1 | AStore_2 | AStore_3
									| AThrow	| BALoad	| BAStore	| BiPush Int
									| CALoad	| CAStore | CheckCast CPIndex
									| D2F	| D2I | D2L | DAdd | DALoad | DAStore
									| DCMPG | DCMPL | DConst_0 | DConst_1 | DDiv
									| DLoad LocalIndex | DLoad_0 | DLoad_1 | DLoad_2 | DLoad_3
									| DMul | DNeg | DRem | DReturn | DStore LocalIndex
									| DStore_0 | DStore_1 | DStore_2 | DStore_3
									| DSub | Dup | Dup_x1 | Dup_x2 | Dup2 | Dup2_x1 | Dup2_x2
									| F2D | F2I | F2L | FAdd | FALoad | FAStore 
									| FCMPG | FCMPL | FConst_0 | FConst_1 | FConst_2 | FConst_3
									| FDiv | FLoad LocalIndex | FLoad_0 | FLoad_1 | FLoad_2
									| FLoad_3 | FMul | FNeg | FRem | FReturn | FStore LocalIndex
									| FStore_0 | FStore_1 | FStore_2 | FStore_3 | FSub 
									| GetField CPIndex | GetStatic CPIndex | Goto Offset
									| GotoW Offset | I2B | I2C | I2D | I2F | I2L | I2S
									| IAdd | IALoad | IAnd | IAStore | IConst_m1 | IConst_0
									| IConst_1 | IConst_2 | IConst_3 | IConst_4 | IConst_5 
									| IDiv | IFACMPEQ Offset | IFACMPNE Offset | IFICMPEG Offset
									| IFCMPNE Offset | IFICMPLT Offset | IFICMPGE Offset
									| IFICMPGT Offset | IFICMPLE Offset | IfEQ Offset
									| IfNE Offset | IfLT Offset | IfGE Offset | IfGT Offset
									| IfLE Offset | IfNonNull Offset | IfNull Offset
									| IInc LocalIndex Int | ILoad LocalIndex | ILoad_0 
									| ILoad_1 | ILoad_2 | ILoad_3 | IMul | INeg
									| InstanceOf CPIndex | InvokeInterface CPIndex Int --Int = count
									| InvokeSpecial 	CPIndex | InvokeStatic  	CPIndex
									| InvokeVirtual 	CPIndex	| IOr | IRem | IReturn | IShl
									| IShr | IStore LocalIndex | IStore_0 | IStore_1
									| IStore_2 | IStore_3 | ISub | IUShr | IXor
									| JSR Offset | JSR_W Offset | L2D | L2F | L2I
									| LAdd | LALoad | LAnd | LAStore | LCmp
									| LConst_0 | LConst_1 | LDC RCPIndex | LDC_W RCPIndex
									| LDC2_W RCPIndex | LDiv | LLoad LocalIndex 
									| LLoad_0 | LLoad_1 | LLoad_2 | LLoad_3 | LMul 
									| LNeg | LookUpSwitch Integer Integer [(Integer, Integer)] | LOr
									| LRem | LReturn | LShl | LShr | LStore LocalIndex
									| LStore_0 | LStore_1 | LStore_2 | LStore_3 | LSub
									| LUShr | LXor | MonitorEnter | MonitorExit   
									| MultiANewArray RCPIndex Int	| New RCPIndex | NewArray JType  
									| NOp | Pop | Pop2 | PutField	RCPIndex | PutStatic RCPIndex
									| Ret LocalIndex | Return | SALoad | SAStore
									| SiPush Int | Swap | TableSwitch Integer Integer Integer [Integer] 
									| Wide_Format1 JInstruction Int	| Wide_Format2 Int Int
									deriving (Eq, Show)

-- Exception Table. Each entry contains, for each type of exception: 
-- 1) the line from which the code could throw the exception
-- 2) the line after which the exception cannot occur
-- 3) the line to jump to after the exception has been successfully elaborated
-- 4) the type of exception
type From 	   			= Int
type To		   				= Int
type Target 	   		= Int
data ExceptionType	= EC String
										| AnyException
										deriving (Eq, Show)

type ExceptionHandler = (From, To, Target, ExceptionType)
data ExceptionTable = ET [ExceptionHandler]
											deriving (Eq, Show)

-- Line Number Table and Local Variable Table.
-- The former indicates couple of line numbers, one in the source code and the other in the method code.
-- The latter indicates XXX: COMPLETA
-- XXX: SKIP THIS ATTRIBUTES?
--type LineNumberEntry 	= (Int, Int)
--type LocalVariableEntry = (Int, Int, Int, String, JType)

-- Method Code. It specifies:
-- 1) the maximum size the local stack can reach XXX:local stack?
-- 2) the maximum number of local variables
-- 3) the maximux size of arguments (i.e. long and double) XXX: check
type StackSize 			= Int
type LocalSize			= Int
type CodeLine 			= (Int, JInstruction)
type MethodCode = [CodeLine]

data VType					= VTTop
										|	VTOneWord
										|	VTTwoWords
										| VTInteger
										| VTFloat
										| VTLong
										| VTDouble
										| VTReference
										| VTUninitialized
										| VTUninitializedThis
										| VTUninitializedOffset 	Offset
										| VTClass	String
										| VTArray VType
										| VTNull
										deriving (Eq, Show)

data VFlag					= FlagThisUninit
										deriving (Eq, Show)

type VStack					= [VType]
type VLocal					= [VType]
data StackFrame 		= SF VLocal VStack [VFlag]
										deriving (Eq, Show)

prjLocalis 	(SF l _ _)	= l
prjStack 		(SF _ s _)	= s
prjFlags 		(SF _ _ f)	= f

type Delta = Int
data StackMap	= SameFrame							Delta
							| SameFrameExtended			Delta
							|	SameLocals						Delta					VType
							| SameLocalsExtended 		Delta					VType
							| ChopFrame							Delta	Offset
							| AppendFrame						Delta	Offset	[VType]
							| FullFrame							Delta	Int	[VType] Int [VType] 
							deriving (Eq, Show)

data CodeAttribute 	= LNT [(Int, Int)] 
										| LVT [(Int, Int, Int, String, JType)] 
										| SMT [StackMap]
										| UnknownCA String 
										deriving (Eq, Show)

-- Method Attributes. They indicate:
-- MethodCode:					the actual code of the method with its relative attributes
-- Synthetic: 					if the method is synthetic, i.e. not present in the source code
-- Deprecated: 					if the method is deprecated
-- LineNumberTable: 		the line in the source code corresponding to a line in the bytecode istructions 
-- LocalVariableTable:	the type corresponding to each local variable
type ExceptionClassName = String
data MethodAttribute 	= MC (MethodCode, (StackSize, LocalSize), Maybe ExceptionTable, [CodeAttribute])
											| DeprecatedMA
											| SyntheticMA
											| MSA MethodType
											| ME [ExceptionClassName]
											| UnknownMA String
											deriving (Eq, Show)

type MethodName 	= String
data ReturnType 	= MRT FieldType 
									| Void
									deriving (Eq, Show)

type ArgumentsTypes 	= [JType]
data MethodType 	= MT (ArgumentsTypes, ReturnType)
									| IgnoredMT String
									deriving (Eq, Show)
type ArgSize 		= Int
type Code				= MethodAttribute
data JMethod 		= JM (MethodName, (MethodType, ArgSize), [MethodAccessFlag], Maybe Code, [MethodAttribute])
								deriving (Eq, Show)

-- Java Class' Body
data JBody = JB [JField] [JMethod]
						deriving (Eq, Show)

-- A disassembled class and its name
type DisassembledClass = (String, JClass)
-- An ordered list of parents of a class
type SuperClassChain = [DisassembledClass]
-- An environment is composed of the classes in the constant pool and their superclass chain
type Environment = [(String, SuperClassChain)]

-- A ClassTree is a hierarchy of classes created from an environment;
-- its nodes are DisassembledClasses coupled with their SearchKey,
-- an element that makes searches on the tree perform on logarithmic time.
type SearchKey = Int
type ClassNode = (DisassembledClass, SearchKey)
type ClassTree = Tree ClassNode

-- A function that returns the superclass chain of its input class name
type SuperClassSearcher = (String -> IO (Maybe SuperClassChain))
