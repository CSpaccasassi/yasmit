module Main where

import System
import System.IO
import System.Console.GetOpt
--import System.Posix.Env
import Text.ParserCombinators.Parsec
import JDisassembler
import JClassData
import JClassPrinter
import JSuperClassChain
import JReconstructor
import Data.Array
import Data.Maybe
import Data.List (nub)
_DEFAULT_LIB_PATH = "/home/carlo/projects/PCC_architecture/SourceCode/javaLib;./"

{-------------------------------
 - MAIN
 -
 - Usage: read a .class file from standard input
 -
 - Options:
 - -f: read .class file from the filesystem
 - -V: print the current version
 - -v: verbose
 - -h: print the usage
 - -o: output file
 -------------------------------}

-- Command options parsing
data Flag = Disassemble
					| Version 
					| Input String 
					| Output String 
					| LibPath String
					deriving Eq

options :: [OptDescr Flag]
options = 
	[ Option ['d']	["disassemble"] (NoArg Disassemble)					"disassemble input class"
	, Option ['v']	["version"]	(NoArg Version)					"show the current version"
	, Option ['L']	["library"]	(ReqArg LibPath "DIR")	"library paths"
	, Option ['i']	["input"]		(ReqArg Input "FILE")		"input FILE"
	, Option ['o']	["output"]  (ReqArg Output "FILE")	"output File"												]

processOptions []						 		= (return stdin, return stdout, False, [_DEFAULT_LIB_PATH], "./")
processOptions (h:t) = case h of
	Input i			-> let (_, o, v, l, _) = processOptions t in ((openFile i ReadMode), o, v, l, getDir i)
	Output o		-> let (i, _, v, l, d) = processOptions t in (i, (openFile o WriteMode), v, l, d)
	Disassemble -> let (i, o, _, l, d) = processOptions t in (i, o, True, l, d)
	LibPath lib	-> let (i, o, v, l, d) = processOptions t in (i, o, v, lib:l, d) -- XXX: separate lib paths

--
---
--

main = do
	args <- getArgs
	case getOpt Permute options args of
		(opt, [], [])	->	do if (elem Version opt)
												then putStrLn $ "Version " ++ show _VERSIONNUMBER
												else _main opt
		(_, errs, [])	->  error $ "Unrecognized arguments: " ++ unwords errs
		(_, _, errs)	->  ioError (userError (concat errs ++ usageInfo "Usage: XXX [OPTIONS]" options))	

-- Get the directory in which a class file is
_getDir s i = case s !! ((length s) -i -1) of
	'/' -> dir
					where (dir, _) = splitAt (i - 1) s
	_		-> _getDir s (i+1)

getDir s = case head s of 
	'.'	->	_getDir s 0
	_		->	"./"

-- Join a list of strings toghether with ';' as separator
joinPaths = foldl1 (\path acc -> path ++ ";" ++ acc)

prjJMethods (JC _ _ (JB _ m)) = m


--
---
--

findClassInCP c cp = case classes of
				[]	->	error $ "Class " ++ c ++ " not found in the constant pool."
				t		-> 	head t
	where	
		(min, max) = bounds cp
		checkSameClass cp c i = case cp ! i of
			MUtf8	s	->	s == c
			_				->	False
		getClass cp c e = case e of
						(n, C	i)	->	if checkSameClass cp c i then Just n else Nothing
						(_, _)		->	Nothing
		classes = catMaybes $ map (getClass cp c) (zip [min..max] (map (\i -> cp ! i) [min..max]))


vtypeHex cp  vt= case vt of
	VTTop										->	u1Hex 0 
	VTInteger								->	u1Hex 1
	VTFloat									->	u1Hex 2
	VTLong									->	u1Hex 4
	VTDouble								->	u1Hex 3
	VTNull									->	u1Hex 5
	VTUninitializedThis			->	u1Hex 6
	VTUninitializedOffset o	->	u1Hex 8 ++ u2Hex o
	VTClass c								->	u1Hex 7 ++ u2Hex (findClassInCP c cp) 
	x												->	error "Unexpected type " ++ show x ++ " in the StackMapTable attribute"
	

stackMapTableToHex cp	[]		=	[]
stackMapTableToHex cp	(x:t)	= case x of
	SameFrame             delta									->	u1Hex delta															++ stackMapTableToHex cp t
	SameFrameExtended     delta									->	u1Hex 251 					++ u2Hex delta			++ stackMapTableToHex cp t
	SameLocals            delta         vtype		->	u1Hex (delta + 64)	++ vtypeHex cp vtype++ stackMapTableToHex cp t
	SameLocalsExtended    delta         vtype		->	u1Hex 247 					++ u2Hex delta 			++ 
																									vtypeHex cp vtype 	++ stackMapTableToHex cp t
	ChopFrame             delta offset					->	u1Hex (251 - offset) ++ u2Hex delta			++ stackMapTableToHex cp t
	AppendFrame           delta offset  vtypes	->	u1Hex (251 + offset) ++ u2Hex delta 		++ 
																									concat (map (vtypeHex cp) (reverse vtypes))	++ stackMapTableToHex cp t

	FullFrame             delta localsCount locals stackCount stack	->	u1Hex 255	++ u2Hex delta ++ 
																									u2Hex localsCount ++ concat (map (vtypeHex cp) (reverse locals)) ++
																									u2Hex stackCount	++ concat (map (vtypeHex cp) (reverse stack)) ++ 
																									stackMapTableToHex cp t


findCodeAttribute	[]									=	([], [], (-1, -1), [])
findCodeAttribute ((_, c, Nothing, _):t)	= (pre, c ++ start, codeAttrCount, end)
	where 
		(pre, start, codeAttrCount, end) = findCodeAttribute t
findCodeAttribute ((p, s, Just a, e):t)	=  (s, p, a, e ++  concat (map (\(_,end,b,c) -> end) t))


catMethodAttribute  cp cpIndex smtCreator	((methodStart, attributes), jmethod)	=	do
	stackMapTable	<- smtCreator	jmethod
	let (p, start, (codeAttributeLength, codeAttributeCount), end) = findCodeAttribute attributes
	if codeAttributeCount == -1	-- if the method has no code
		then 	return $ methodStart ++ start
		else case stackMapTable of
			Just smt	->	do
--				putStrLn $ concat $ map show smt
				let name	=	u2Hex cpIndex
				let body = stackMapTableToHex cp smt
				let smtString	=	name ++ u4Hex (length body + 2) ++ u2Hex (length smt) ++ body

--				return $ "AAAAAAAAAAAAH---" ++ smtString

				return $ methodStart ++ start ++ u4Hex (codeAttributeLength + length smtString)++ p 
														 ++ u2Hex (codeAttributeCount + 1) ++ end ++ smtString
			--	return $ start ++ u2Hex (attributeCount + 1)	++ end ++ smtString
			Nothing		->	return $ methodStart ++ start ++ u4Hex codeAttributeLength ++ p 
														 ++ u2Hex codeAttributeCount  ++ end
--			methodStart ++ start -- ++ u2Hex attributeCount ++ end



_main opt = do
	let (inputH, outputH, verbose, libPaths, classPath) = processOptions opt
	let currClassPath = classPath --if classPath == "./" then "./" else classPath
	inputHandle <- inputH
	bytecode 		<- hGetContents inputHandle
	case (runParser classDisassembler "" "" bytecode) of
		Right (s, jclass) 	-> if verbose
			then 	prettyPrint jclass
			else do	
				let cp 				= prjCP jclass
				-- Check that the stackMapRable Attribute has not already been defined
				let (min, max) =bounds cp
				let stackMapTableChecks = map  (\i -> ((cp ! i) == (MUtf8 "StackMapTable"))) [min..max]
				if or stackMapTableChecks
					then 	putStrLn "StackMapTable already present.\n"
					else	do
						let className = prjClass_CN
	{-					putStrLn currClassPath
						putStrLn $ concat libPaths-}
						environment <-	getEnvironment cp (joinPaths $ nub $ currClassPath : libPaths)
						superClassChainSearcher		<-	buildClassHierarchy environment
						let stackMapCreator	= createStackMapTable superClassChainSearcher jclass
						case (runParser modifyClass "" "" bytecode) of
							Right (start, mStrings, end)	->	 	do
										-- Create stack maps, translate them to strings and insert them in the code								
										methodCodes <- mapM (catMethodAttribute cp (max + 1) stackMapCreator)(zip mStrings (prjJMethods jclass))
			--							putStr end
										putStr $ start ++ concat methodCodes ++ end
							Left 	fail -> do putStrLn "Class file modifying failed:\n" ; print fail
				--return ()-}
		Left fail			-> do putStrLn "Class file parsing failed:\n" ; print fail
