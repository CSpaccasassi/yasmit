module JParser where

import Char 
import Text.ParserCombinators.Parsec
import Text.ParserCombinators.Parsec.Token
import Text.ParserCombinators.Parsec.Prim (try)
import Array
import Data.Bits

{---------------------
 - ------------------
 - PARSING UTILITIES
 - ------------------
 ---------------------}

type JParser a = CharParser String a

x << n = shift x n

u1check :: Int -> JParser Char
u1check i = do
	c <- char $ chr i
	updateState (++ [c])
	return c
	<?> "expecting char-code " ++ show i

u1 :: JParser Int
u1 = do
	c <- anyChar
	updateState (++ [c])
	return $ ord c

u2 :: JParser Int
u2 = do
	upper <- u1
	lower <- u1
	return $ (upper << 8) + lower

u4 :: JParser Int
u4 = do 
	uu <- u1
	ul <- u1
	lu <- u1
	ll <- u1
	return $ (uu << 24) + (ul << 16) + (lu << 8) + ll

signed_u4 :: Int -> Integer
signed_u4 i = if (testBit i 31 == True)
						  	then (unsigned * (-1))
		        		else unsigned
							 where unsigned = fromIntegral (i .&. 0x7FFFFFFF)

