module JOpcodes where

{-------------------------------------------
 - Module JClassOpCode
 -
 - This module contains the function
 -
 - 					disassembleCode
 -
 - It has two arguments: 
 - 1) length
 - 3) cp
 -
 - This function parses the opcode of Java
 - instructions; its arguments are the length 
 - of the code to parse in bytes and the Constant
 - Pool. Note that length is not the actual 
 - number of instructions, since the size of 
 - instructions is not always one byte: 
 - some opcodes have arguments as well. 
 - 
 - disassembleCode returns a list of this type:
 - 	
 - 		[(Int, JInstruction)]
 -
 - Each element of the list represents an
 - instruction: the first component is the line
 - of the instruction, the second is the 
 - instruction itself.
 - ----------------------------------------}

import Text.ParserCombinators.Parsec
import Text.ParserCombinators.Parsec.Token
import Text.ParserCombinators.Parsec.Prim  (try)
import Text.ParserCombinators.Parsec.Error (errorMessages, messageString)
import JClassData
import JParser
import Char (ord, chr)
import Data.Bits 
----------------------------------------------

type OCParser a = GenParser  Int (Int, Int) a

bsatisfy f = tokenPrim 
             (\s -> show s) 
						 (\pos _ _ -> incSourceLine pos 1) 
						 (\s -> if f s then Just s else Nothing)

anyInt = bsatisfy (\_ -> True)

o1check :: Int -> OCParser Int
o1check i = do
	c <- try(do
		rc <- o1
		if (rc == i) then return rc
			else fail $ "expecting " ++ show  i ++ ", found " ++ show rc
		)
	return c
	<?> "expecting char-code " ++ show i ++ "\n"

o1 :: OCParser Int
o1 = do
	c <- anyInt
	updateState (\(length, line) -> (length -1, line + 1))
	return $ c

o2 :: OCParser Int
o2 = do
	upper <- o1 
	lower <- o1
	return $ (upper << 8) + lower
	 
o4 :: OCParser Int
o4 = do 
	uu <- o1
	ul <- o1
	lu <- o1
	ll <- o1												 
	return $ (uu << 24) + (ul << 16) + (lu << 8) + ll



signed_o2 :: Int -> Integer
signed_o2 i =	if (testBit i 15 == True)
			then signed
			else fromIntegral i
				where signed = fromIntegral (i -0xFFFF -1)

signed_o4 :: Int -> Integer
signed_o4 i =	if (testBit i 31 == True)
			then (unsigned * (-1))
			else unsigned
				where unsigned = fromIntegral (i .&. 0x7FFFFFFF)
-- NOTE: opcodes are written as integers,
--       not as hexadecimal numbers
opcode :: Int -> OCParser Int
opcode i = try (o1check i) 

{-----------------------
 - --------------------
 - OPCODE DISASSEMBLER
 - --------------------
 -----------------------}

aaload = do
	opcode 50
	return AALoad

aastore = do
	opcode 83
	return AAStore

aconst_null = do
	opcode 1
	return AConst_Null

aload = do
	opcode 25
	i <- o1
	return $ ALoad i

aload_0 = do
	opcode 42
	return ALoad_0

aload_1 = do
	opcode 43
	return ALoad_1

aload_2 = do
	opcode 44
	return ALoad_2

aload_3 = do
	opcode 45
	return ALoad_3

anewarray = do	
	opcode 189
	cpIndex <- o2
	return $ ANewArray cpIndex

areturn = do
	opcode 176
	return AReturn

arraylength = do
	opcode 190
	return ArrayLength

astore = do
	opcode 58
	localIndex	<- o1
	return $ AStore localIndex

astore_0 = do
	opcode 75 
	return AStore_0

astore_1 = do
	opcode 76 
	return $ AStore_1

astore_2 = do
	opcode 77
	return AStore_2

astore_3 = do
	opcode 78
	return AStore_3

athrow = do
	opcode 191
	return AThrow

baload = do
	opcode 51
	return BALoad

bastore = do
	opcode 84
	return BAStore

bipush = do
	opcode 16
	byte	<- o1
	return	$ BiPush byte

caload = do
	opcode 52
	return CALoad

castore = do
	opcode 85
	return CAStore

checkcast = do
	opcode 192
	cpIndex <- o2
	return $ CheckCast cpIndex

d2f = do
	opcode 144 
	return D2F

d2i = do
	opcode 142
	return D2I

d2l = do
	opcode 143
	return D2L

dadd = do
	opcode 99
	return DAdd

daload = do
	opcode 49
	return DALoad

dastore = do
	opcode 82
	return DAStore


dcmpg = do
	opcode 152 
	return DCMPG

dcmpl = do 
	opcode 151
	return DCMPL

dconst_0 = do
	opcode 14 
	return DConst_0

dconst_1 = do
	opcode 15
	return DConst_1

ddiv = do
	opcode 111
	return DDiv

dload = do
	opcode 24
	localIndex <- o1
	return $ DLoad localIndex

dload_0 = do
	opcode 38 
	return DLoad_0

dload_1 = do
	opcode 39 
	return DLoad_1

dload_2 = do
	opcode 40
	return DLoad_2

dload_3 = do
	opcode 41
	return DLoad_3

dmul = do
	opcode 107
	return DMul

dneg = do
	opcode 119
	return DNeg

drem = do
	opcode 115
	return DRem

dreturn = do
	opcode 175
	return DReturn

dstore = do
	opcode 57
	localIndex <- o1
	return $ DStore localIndex

dstore_0 = do
	opcode 71
	return DStore_0

dstore_1 = do
	opcode 72 
	return DStore_1

dstore_2 = do
	opcode 73 
	return DStore_2

dstore_3 = do
	opcode 74
	return DStore_3

dsub = do
	opcode 103
	return DSub

dup = do
	opcode 89
	return Dup

dup_x1 = do
	opcode 90
	return Dup_x1

dup_x2 = do
	opcode 91
	return Dup_x2

dup2 = do
	opcode 92
	return Dup2

dup2_x1 = do
	opcode 93
	return Dup2_x1

dup2_x2 = do
	opcode 94
	return Dup2_x2

f2d = do
	opcode 141
	return F2D

f2i = do
	opcode 139
	return F2I

f2l = do
	opcode 140
	return F2L

fadd = do
	opcode 98
	return FAdd

faload = do
	opcode 48
	return FALoad

fastore = do
	opcode 81
	return FAStore

fcmpg = do
	opcode 150 
	return FCMPG

fcmpl = do
	opcode 149
	return FCMPL

fconst_0 = do
	opcode 11 
	return FConst_0
	
fconst_1 = do
	opcode 12 
	return FConst_1
	
fconst_2 = do
	opcode 13
	return FConst_2

fdiv = do
	opcode 110
	return FDiv

fload = do
	opcode 23
	localIndex <- o1
	return $ FLoad localIndex

fload_0 = do
	opcode 34 
	return FLoad_0

fload_1 = do 
	opcode 35 
	return FLoad_1

fload_2 = do 
	opcode 36 
	return FLoad_2
	
fload_3 = do
	opcode 37
	return FLoad_3

fmul = do
	opcode 106
	return FMul

fneg = do
	opcode 118
	return FNeg

frem = do 
	opcode 114
	return FRem

freturn = do
	opcode 174
	return FReturn

fstore = do
	opcode 56
	localIndex <- o1
	return $ FStore localIndex 

fstore_0 = do
	opcode 67 
	return FStore_0

fstore_1 = do
	opcode 68 
	return FStore_1

fstore_2 = do
	opcode 69
	return FStore_2

fstore_3 = do
	opcode 70
	return FStore_3

fsub = do
	opcode 102
	return FSub

getField = do
	opcode 180
	cpIndex <- o2
	return $ GetField cpIndex

getStatic = do
	opcode 178
	cpIndex <- o2
	return $ GetStatic cpIndex

goto = do
	opcode 167
	offset <- o2
	return $ Goto $ fromIntegral $ signed_o2 offset

gotow = do
	opcode 200
	offset <- o4
	return $ GotoW $ fromIntegral $ signed_o4 offset

i2b = do 
	opcode 145
	return I2B

i2c = do
	opcode 146
	return I2C

i2d = do
	opcode 135
	return I2D

i2f = do
	opcode 134
	return I2F

i2l = do
	opcode 133
	return I2L

i2s = do 
	opcode 147
	return I2S

iadd = do
	opcode 96
	return IAdd

iaload = do 
	opcode 46
	return IALoad

iand = do
	opcode 126
	return IAnd

iastore = do
	opcode 79
	return IAStore

iconst_m1 = do
	opcode 2
	return IConst_m1
	
iconst_0 = do
	opcode 3
	return IConst_0
	
iconst_1 = do 
	opcode 4
	return IConst_1 
	
iconst_2 = do
	opcode 5 
	return IConst_2
	
iconst_3 = do
	opcode 6
	return IConst_3
	
iconst_4 = do
	opcode 7 
	return IConst_4 
	
iconst_5 = do
	opcode 8
	return IConst_5

idiv = do
	opcode 108
	return IDiv

if_acmpeq = do
	opcode 165 
	offset <- o2
	return $ IFACMPEQ offset
	
if_acmpne = do
	opcode 166
	offset <- o2
	return $ IFACMPNE offset

if_icmpeq = do
	opcode 159 
	offset <- o2
	return $ IFICMPEG offset

if_icmpne = do
	opcode 160 
	offset <- o2
	return $ IFCMPNE offset
	
if_icmplt = do
	opcode 161 
	offset <- o2
	return $ IFICMPLT offset

if_icmpge = do
	opcode 162 
	offset <- o2
	return $ IFICMPGE offset
	
if_icmpgt = do
	opcode 163 
	offset <- o2
	return $ IFICMPGT offset

if_icmple = do
	opcode 164
	offset <- o2
	return $ IFICMPLE offset

ifeq = do
	opcode 153 
	offset <- o2
	return $ IfEQ offset

ifne = do
	opcode 154 
	offset <- o2
	return $ IfNE offset

iflt = do
	opcode 155 
	offset <- o2
	return $ IfLT offset 
	
ifge = do
	opcode 156 
	offset <- o2
	return $ IfGE offset

ifgt = do
	opcode 157 
	offset <- o2
	return $ IfGT offset

ifle = do
	opcode 158
	offset <- o2
	return $ IfLE offset

ifnonnull = do
	opcode 199
	offset <- o2
	return $ IfNonNull offset 

ifnull = do
	opcode 198
	offset  <- o2
	return $ IfNull offset 

iinc = do 
	opcode 132
	localIndex <- o1
	const <- o1
	return $ IInc localIndex const

iload = do
	opcode 21
	localIndex <- o1
	return $ ILoad localIndex 

iload_0 = do
	opcode 26 
	return ILoad_0

iload_1 = do
	opcode 27 
	return ILoad_1

iload_2 = do
	opcode 28
	return ILoad_2
	
iload_3 = do
	opcode 29
	return ILoad_3

imul = do 
	opcode 104
	return IMul

ineg = do
	opcode 116
	return INeg

instanceof = do
	opcode 193
	cpIndex <- o2
	return $ InstanceOf cpIndex 

invokeinterface = do
	opcode 185
	cpIndex <- o2
	count <- o1
	opcode 0
	if (count == 0) 
		then fail $ "field count in invokeInterface bytecode is zero."
		else return $ InvokeInterface cpIndex count

invokespecial = do
	opcode 183
	cpIndex <- o2
	return $ InvokeSpecial cpIndex

invokestatic = do 
	opcode 184
	cpIndex <- o2
	return $ InvokeStatic cpIndex

invokevirtual = do
	opcode 182
	cpIndex <- o2
	return $ InvokeVirtual cpIndex

ior = do
	opcode 128
	return IOr

irem = do
	opcode 112
	return IRem

ireturn = do
	opcode 172
	return IReturn

ishl = do
	opcode 120
	return IShl

ishr = do
	opcode 122
	return IShr

istore = do
	opcode 54
	localIndex <- o1
	return $ IStore localIndex

istore_0 = do
	opcode 59
	return IStore_0
	
istore_1 = do
	opcode 60
	return IStore_1

istore_2 = do
	opcode 61
	return IStore_2

istore_3 = do
	opcode 62
	return IStore_3

isub = do
	opcode 100
	return ISub

iushr = do
	opcode 124
	return IUShr

ixor = do
	opcode 130
	return IXor

jsr = do
	opcode 168
	offset <- o2
	return $ JSR offset

jsr_w = do
	opcode 201
	offset <- o4
	return $ JSR_W offset

l2d = do
	opcode 138
	return L2D

l2f = do
	opcode 137
	return L2F

l2i = do
	opcode 136
	return L2I

ladd = do 
	opcode 97
	return LAdd

laload = do
	opcode 47
	return LALoad

land = do
	opcode 127
	return LAnd

lastore = do
	opcode 80
	return LAStore

lcmp = do
	opcode 148
	return LCmp

lconst_0 = do
	opcode 9
	return LConst_0

lconst_1 = do
	opcode 10
	return LConst_1

ldc = do
	opcode 18
	rcpIndex <- o1
	return $ LDC rcpIndex

ldc_w = do
	opcode 19
	rcpIndex <- o2
	return $ LDC_W rcpIndex

ldc2_w = do
	opcode 20
	rcpIndex <- o2
	return $ LDC2_W rcpIndex

ldiv = do
	opcode 109
	return LDiv

lload = do
	opcode 22
	localIndex <- o1
	return $ LLoad localIndex

lload_0 = do
	opcode 30
	return LLoad_0

lload_1 = do
	opcode 31
	return LLoad_1

lload_2 = do
	opcode 32
	return LLoad_2

lload_3 = do
	opcode 33
	return LLoad_3

lmul = do
	opcode 105
	return LMul

lneg = do
	opcode 117
	return LNeg

skipZeros = do
	(_, line) <- getState
	if (mod line 4 == 0)
		then return []
		else mapM (\_ -> o1) [1..(4 - (mod line 4))]
	
matchOffset_pair = do
	match <- o4
	offset <- o4
	return (signed_o4 match, signed_o4 offset)


lookupswitch = do
	opcode 171
	skipZeros
	defaultByte1 	<- o1
	defaultByte2 	<- o1
	defaultByte3 	<- o1
	defaultByte4 	<- o1
	let defaultByte = fromIntegral $ (defaultByte1 << 24) + (defaultByte2 << 16) + (defaultByte3 << 8) + defaultByte4
	pairsCount' 	<- o4
	let pairsCount = fromIntegral pairsCount'
	if (pairsCount == 0)
		then return $ LookUpSwitch defaultByte pairsCount []
		else if (pairsCount > 0) 
			then do
				pairs <- mapM (\_ -> matchOffset_pair) [1..pairsCount]
				return $ LookUpSwitch defaultByte pairsCount pairs
			else fail $ "negative pairsCount in lookupswitch instruction: found " ++ show pairsCount

lor = do
	opcode 129
	return LOr

lrem = do
	opcode 113
	return LRem

lreturn = do
	opcode 173
	return LReturn

lshl = do
	opcode 121
	return LShl

lshr = do
	opcode 123
	return LShr

lstore = do
	opcode 55
	localIndex <- o1
	return $ LStore localIndex

lstore_0 = do
	opcode 63
	return LStore_0

lstore_1 = do
	opcode 64 
	return LStore_1

lstore_2 = do
	opcode 65
	return LStore_2
	
lstore_3 = do
	opcode 66
	return LStore_3

lsub = do
	opcode 101
	return LSub

lushr = do
	opcode 125
	return LUShr

lxor = do
	opcode 131
	return LXor

monitorenter = do
	opcode 194
	return MonitorEnter

monitorexit = do
	opcode 195
	return MonitorExit

multianewarray = do
	opcode 197
	rcpIndex <- o2
	dimensions <- o1
	if (dimensions >= 1)
		then return $ MultiANewArray rcpIndex dimensions
		else fail $ "zero dimension found in multianewarray instruction."

new = do
	opcode 187
	rcpIndex <- o2
	return $ New rcpIndex

newarray = do
	opcode 188
	atype <- o1
	let arrayType = case atype of
						4		->	Jbool
						5		->	Jchar
						6		->	Jfloat
						7		->	Jdouble
						8		->	Jbyte
						9		->	Jshort
						10	->	Jint
						11	->	Jlong
	return $ NewArray arrayType

nop = do
	opcode 0
	return NOp

pop = do
	opcode 87
	return Pop

pop2 = do
	opcode 88
	return Pop2

putfield = do
	opcode 181
	rcpIndex <- o2
	return $ PutField rcpIndex
	
putstatic = do
	opcode 179
	rcpIndex <- o2
	return $ PutStatic rcpIndex

ret = do
	opcode 169
	localIndex <- o1
	return $ Ret localIndex

jreturn = do
	opcode 177
	return Return

saload = do
	opcode 53
	return SALoad

sastore = do
	opcode 86
	return SAStore

sipush = do
	opcode 17
	i <- o2
	return $ SiPush i

swap = do
	opcode 95
	return Swap

tableSwitchEntry = do
	offsetWord <- o4
	return (signed_o4 offsetWord)

tableswitch = do
	opcode 170
	skipZeros
	defaultByte1 <- o1
	defaultByte2 <- o1
	defaultByte3 <- o1
	defaultByte4 <- o1
	lowWord 	<- o4
	highWord	<- o4
	let defaultWord = fromIntegral $ (defaultByte1 << 24) + (defaultByte2 << 16) + (defaultByte3 << 8) + defaultByte4
	let low 				= fromIntegral lowWord 
	let high	 			= fromIntegral highWord 	
	if (low <= high) 
		then do
			let count = high - low + 1
			offsets <- mapM (\_ -> tableSwitchEntry) [1..count]
			return $ TableSwitch defaultWord low high offsets
		else fail $ "Found low > high in tableswitch instruction: " ++ show low ++ " > " ++ show high
	
-- The instructions in this table are all initialized to -1
-- so that they are unusable: they only represent the instruction
-- corresponding to an opcode
wide_format1_opcodes =	[	(21, ILoad 	(-1)),
													(23, FLoad 	(-1)),
													(25, ALoad	(-1)),
													(22, LLoad	(-1)), 
													(24, DLoad	(-1)),
													(54, IStore	(-1)),
													(56, FStore	(-1)),
													(50, AStore	(-1)),
													(55, LStore	(-1)),
													(57, DStore	(-1)),
													(169, Ret		(-1))	]

wide_format2_opcode = 132	

wide = do
	opcode 196
	format <- o1
	localIndex <- o2
	if (foldl (\c (a, b) -> if (format == a) then True else c) False wide_format1_opcodes)
		then 
			case (foldl (\ c (a, b) -> if (format == a) then b else c) NOp wide_format1_opcodes) of
				NOp	-> fail $ "Unsupported opcode in the wide instruction: found "  ++ show format
				x		-> return $ Wide_Format1 x localIndex 	
		else if (format == wide_format2_opcode)
			then do
				const <- o2
				return $ Wide_Format2 localIndex const
			else fail $ "Unrecognized format opcode in instruction wide: found " ++ show format


--
----------
--------
----------
--------
----------
--

disassembleInstruction :: OCParser JInstruction
disassembleInstruction = 
	aaload 				<|> aastore 	<|> aconst_null <|> aload 					<|>	aload_0 			<|> aload_1 			<|> 
	aload_2 			<|> aload_3 	<|> anewarray 	<|>	areturn 				<|>	arraylength 	<|> astore 				<|> 
	astore_0 			<|> astore_1 	<|> astore_2 		<|> astore_3 				<|>	athrow 				<|> baload 				<|> 
	bastore 			<|> bipush 		<|> caload 			<|> castore 				<|> checkcast 		<|>	d2f 					<|> 
	d2i 					<|> d2l 			<|> dadd 				<|> daload 					<|> dastore 			<|> dcmpg 				<|>	
	dcmpl 				<|> dconst_0 	<|> dconst_1 		<|> ddiv 						<|> dload 				<|> dload_0 			<|> 
	dload_1 			<|> dload_2 	<|> dload_3 		<|> dmul 						<|> dneg 					<|> drem 					<|> 
	dreturn 			<|> dstore 		<|> dstore_0 		<|> dstore_1 				<|> dstore_2 			<|> dstore_3			<|> 
	dsub 					<|> dup 			<|> dup_x1 			<|> dup_x2  				<|>	dup2 					<|> dup2_x1 			<|> 
	dup2_x2  			<|> f2d 			<|> f2i 				<|> f2l 						<|> fadd 					<|> faload 				<|> 
	fastore 			<|>	fcmpg 		<|> fcmpl 			<|> fconst_0 				<|> fconst_1 			<|> fconst_2 			<|> 
	fdiv 					<|> fload 		<|>	fload_0 		<|> fload_1 				<|> fload_2 			<|> fload_3 			<|> 
	fmul 					<|> fneg 			<|> frem 				<|> freturn 				<|> fstore 				<|> fstore_0 			<|> 
	fstore_1 			<|>	fstore_2 	<|> fstore_3 		<|> fsub 						<|> getField 			<|> getStatic			<|> 
	goto 					<|> gotow 		<|>	i2b 				<|> i2c 						<|> i2d 					<|> i2f 					<|>	
	i2l						<|> i2s 			<|>  iadd 			<|> iaload 					<|> iand 					<|>	iastore 			<|> 
	iconst_m1 		<|> iconst_0 	<|> iconst_1 		<|> iconst_2 				<|> iconst_3 			<|>	iconst_4 			<|> 
	iconst_5 			<|> idiv 			<|> if_acmpeq 	<|> if_acmpne 			<|> if_icmpeq 		<|> if_icmpne 		<|> 
	if_icmplt 		<|> if_icmpge <|> if_icmpgt 	<|> if_icmple 			<|> ifeq 					<|> ifne 					<|> 
	iflt 					<|> ifge 			<|> ifgt 				<|> ifle 						<|>	ifnonnull 		<|> ifnull 				<|> 
	iinc 					<|> iload 		<|> iload_0 		<|> iload_1 				<|>	iload_2 			<|> iload_3 			<|> 
	imul 					<|> ineg 			<|> instanceof 	<|> invokeinterface <|>	invokespecial	<|> invokestatic	<|> 
	invokevirtual	<|> ior 			<|> irem				<|>	ireturn 				<|> ishl 					<|>	ishr 					<|> 
	istore 				<|> 
	istore_0 			<|> istore_1 	<|> istore_2 		<|> istore_3 				<|> isub 					<|>	iushr 				<|> 
	ixor 					<|> jsr 			<|> jsr_w 			<|> l2d 						<|> l2f 					<|> l2i 					<|> 
	ladd 					<|> laload 		<|> land 				<|> lastore 				<|> lcmp 					<|> lconst_0 			<|> 
	lconst_1 			<|> ldc 			<|>	ldc_w 			<|> ldc2_w 					<|> ldiv 					<|> lload 				<|> 
	lload_0 			<|> lload_1 	<|>	lload_2 		<|> lload_3 				<|> lmul 					<|> lneg 					<|> 
	lookupswitch 	<|> lor				<|> lrem 				<|> lreturn 				<|> lshl 					<|> lshr 					<|> 
	lstore 				<|> lstore_0 	<|> lstore_1 		<|> lstore_2 				<|> lstore_3 			<|> lsub 					<|> 
	lushr 				<|> lxor 			<|>	monitorenter<|> monitorexit 		<|> multianewarray<|> new 					<|> 
	newarray 			<|> nop 			<|>	pop 				<|> pop2 						<|>	putfield 			<|> putstatic 		<|> 
	ret 					<|> jreturn 	<|> saload 			<|> sastore 				<|> sipush 				<|> swap 					<|> 
	tableswitch 	<|> wide
	<?> "Unrecognized instruction.\n"


disassembleCodeLoop cp code = do
	(length, line) <- getState
	if (length == 0) then return code
		else if (length > 0) then  do
																	instr <- disassembleInstruction
																	disassembleCodeLoop cp (code ++ [(line, instr)])
				else fail $ "Incorrect code length."
--XXX: DECIDE WHETHER name MUST REMAIN OR NOT
disassembleCode :: [Int] -> Int -> ConstantPool -> String -> JParser [CodeLine]--XXX:HERE
disassembleCode rawcode length cp name = do
	case (runParser  (disassembleCodeLoop cp []) (length, 0) "" rawcode) of
		Right code	-> 	return code
		Left s			->	fail $ "Code parsing failed in method "++ name++".\n" ++ (concat $ map messageString (errorMessages s))	--XXX:HERE
														++ "\n\n\nRaw Code:\n" ++  map chr rawcode ++ "\n"
