module JClassPrinter where

import Array
import JClassData
import Data.List(intersperse)

-- XXX: TODO: MOVE entryAt TO Utilities

-- extracts i-th element of the constant pool
entryAt :: Int -> ConstantPool -> CPEntry
entryAt i cp = cp ! i

-- concatenate the contents of an entry throughout the various constant pool entries
entryString entry cp = case entry of
	MUtf8 s		-> s
	S i				-> entryString (entryAt i  cp) cp
	NT i1 i2	-> entryString (entryAt i1 cp) cp ++ " of type " ++ entryString (entryAt i2 cp) cp
	C i				-> entryString (entryAt i  cp) cp
	MR i1 i2	-> entryString (entryAt i1 cp) cp ++ ": " ++ entryString (entryAt i2 cp) cp
	IMR i1 i2	-> entryString (entryAt i1 cp) cp ++ ": " ++ entryString (entryAt i2 cp) cp
	FR i1 i2	-> entryString (entryAt i1 cp) cp ++ ": " ++ entryString (entryAt i2 cp) cp
	I int			-> show int
	L long		-> show long
	F float		-> show float
	D double	-> show double

stringAt i cp = entryString (entryAt i cp) cp

{-----------------------------
 -----------------------------
 - BODY PRINTER
 -----------------------------
 ----------------------------}
-- Methods Printer

methodAccessFlagToString af = case af of
	 PublicM  			-> "public"
	 PrivateM  			-> "private"
	 ProtectedM 		-> "protected"
	 PackageM				-> "package"
	 FinalM   			-> "final"
	 AbstractM  		-> "abstract"
	 StaticM   			-> "static"
	 SynchronizedM 	-> "synchronized"
	 NativeM				-> "native"
	 StrictM   			-> "strict"
	 BridgeM     		-> "bridge"
	 VarArgsM				-> "varArgs"
	 SyntheticM			-> "synthetic"


returnTypeToString t = case t of
	MRT t		-> jtypeToString t
	Void		-> "void"

instructionToString (i, istr) cp = 
	show i ++ ") " ++ case istr of
		New 		i 					-> "new " 					++ stringAt i cp ++ "\n"
		Dup 								-> "dup" 						++ "\n"
		ALoad 		n 				->  "aload "				++ show n     	 ++ "\n"
		InvokeSpecial   i 	-> "invokespecial "	++ stringAt i cp ++ "\n"
		InvokeVirtual   i 	-> "invokevirtual "	++ stringAt i cp ++ "\n"
		InvokeStatic    i 	-> "invokestatic " 	++ stringAt i cp ++ "\n"
		PutField        i 	-> "putfield " 			++ stringAt i cp ++ "\n"
		GetField        i 	-> "getfield " 			++ stringAt i cp ++ "\n"
		Return 							-> "return" 				++ "\n"
		GetStatic       i 	-> "getstatic " 		++ stringAt i cp ++ "\n"--XXX: supported?
		PutStatic       i 	-> "putstatic " 		++ stringAt i cp ++ "\n" --XXX: supported?
		--Ldc             i 	-> "ldc " 					++ stringAt i cp ++ "\n" --XXX: supported?
		AReturn  						-> "areturn" 				++ "\n"

exceptionClassToString c = 
	case c of
		EC s					->	s
		AnyException	-> "any exception"

exceptionTableEntryToString (i, j, t, s) =
	show i ++ "\t" ++ show j ++ "\t" ++ show t ++ "\t" ++ exceptionClassToString s ++ "\n"	

exceptionTableToString (ET t) =
	"Exception Table:\n" ++ concat (map exceptionTableEntryToString t)

codeAttributesToString	[] = "\n"
codeAttributesToString ((UnknownCA s): t) = "Unknown code attribute " ++ s ++ "\n" ++ (codeAttributesToString t)
codeAttributesToString ((LNT table): t)		= lineNumberTableToString table ++ codeAttributesToString t
codeAttributesToString ((LVT table): t)		= localVariableTableToString table ++ codeAttributesToString t

methodCodeToString (Just (MC (code ,(stack, locals), excTable, codeAttributes))) cp = 
	   "Stack: " 	++ show stack ++ " Locals: " ++ show locals ++ "\n"
								++ concat (map (\(a, b) -> show a ++ ")\t" ++  show  b ++ "\n") code)
								++ case excTable of 
										Nothing -> "\n"
										Just x  -> exceptionTableToString x
								++ codeAttributesToString	codeAttributes	

methodCodeToString Nothing cp = "No code."

--methodCodeToString (x) cp = show x

lineNumberTableEntryToString (i, j) = "line " ++ show i ++ ":\t" ++ show j ++ "\n"
lineNumberTableToString t = 
	"Line Number Table:\n" ++ concat (map lineNumberTableEntryToString t)

localVariableTableEntryToString (i, j, n, s, t) = 
	show i ++ "\t" ++  show j ++ "\t" ++ show n ++ "\t" ++ s ++ "\t" ++ jtypeToString t ++ "\n"
localVariableTableToString t = 
	"Local Variable Table:\n" ++ concat (map localVariableTableEntryToString t)

methodSignatureToString sig = case sig of
	MT (args, ret)	->	"Method Signature: " ++ "(" ++ unwords (map jtypeToString args) ++ ")" ++ show ret
	IgnoredMT	s			->	"Ignored Method Signature: " ++ s

methodAttributeToString a = case a of
	SyntheticMA			-> "Synthetic method.\n"
	DeprecatedMA		-> "Deprecated method.\n"
	MSA	signature 	-> 	methodSignatureToString signature
	ME list					-> "Method Exceptions: " ++ unwords list
	UnknownMA s			-> "Unknown method attribute " ++ s
--	LNT t		-> lineNumberTableToString t
--	LVT t		-> localVariableTableToString t


prettyPrintMethods [] cp = putStrLn "End of input\n"
prettyPrintMethods ((JM (name, (signature, argsSize), acc, code, attr)):t) cp = do
	putStr $	unwords (map methodAccessFlagToString acc) ++ " " 
				++	case signature of
					MT (args, ret) ->	returnTypeToString ret ++ " " ++	"(" ++ unwords (map jtypeToString args) ++ "):\n" 
					IgnoredMT s		 -> s
				++	methodCodeToString code cp
				++	concat (map methodAttributeToString attr)
				++	"\n"
	prettyPrintMethods t cp
	

-- Fields Printer
fieldAccessFlagToString af = do
	case af of
	 PublicF  	-> "public"
	 PrivateF  	-> "private"
	 ProtectedF -> "protected"
	 PackageF		-> "package"
	 FinalF   	-> "final"
	 VolatileF  -> "volatile"
	 TransientF -> "transient"
	 StaticF		-> "Static"
	 EnumF			-> "Enumeration"
	 SyntheticF	-> "Synthetic"
	  
		

jtypeToString t = 
	case t of
	 Jbyte 		-> "byte"
	 Jchar 		-> "char"
	 Jdouble 	-> "double"
	 Jfloat 	-> "float"
	 Jint  		-> "int"
	 Jlong 		-> "long"
	 Jbool   	-> "bool"
	 Jshort 	-> "short"
	 Jclass s 	-> "class " ++ s
	 Jarray ref	-> jtypeToString ref ++ "[]"

fieldAttributeToString cp attr = case attr of 
	 CFV index				-> "ConstantValue: " ++	entryString (entryAt index cp) cp
	 SyntheticFA 			-> "SynthethicField"
	 DeprecatedFA			-> "DeprecatedField"
	 FS	t							-> "Field Signature: " ++ jtypeToString t
	 UnknownFA	s			-> "Unrecognized field attribute " ++ s


prettyPrintFields []  _ = putStrLn "-----------------------------------------"
prettyPrintFields ((JF (name, sig, acc, attr)):t) cp = do
	putStr $    unwords (map fieldAccessFlagToString acc) ++ " " 
		 ++ jtypeToString sig ++ " " 
		 ++ name ++ ";"
	putStrLn $ unwords (map (fieldAttributeToString cp) attr)
	prettyPrintFields t cp

-- Body Printer
prettyPrintBody (JB fields methods) cp = do
	putStrLn $ show (length fields) ++ " fields:"
	prettyPrintFields  fields cp
	putStrLn $ show (length methods) ++ " methods:"
	prettyPrintMethods methods cp

{----------------------------
 ----------------------------
 - CONSTANT POOL PRINTER
 ----------------------------
 ---------------------------}
-- Create the string representing an entry in the constant pool
prettyPrintEntry entry cp = case entry of
	MUtf8 _		-> "Raw String: \t"						++ entryString entry cp
	S  _			-> "Java string: \t" 					++ entryString entry cp
	NT _ _ 		-> "NameAndType: \t" 					++ entryString entry cp
	C  _			-> "Class: \t" 								++ entryString entry cp
	MR  _ _		-> "Method: \t" 							++ entryString entry cp
	IMR _ _		-> "Interface Method: \t"			++ entryString entry cp
	FR  _ _		-> "Field: \t"	 							++ entryString entry cp
	I _				-> "Java 32 bit integer: \t" 	++ entryString entry cp
	L _				-> "Java 64 bit integer: \t" 	++ entryString entry cp
	F _				-> "Java float: \t"						++ entryString entry cp
	D _				-> "Java double: \t"					++ entryString entry cp
	Unusable	-> "Unusable entry"

prettyPrintConstantPool cp l = putStrLn $ (++) "Constant Pool:\n " 
					$ unwords 
					$ map (\ i -> show i ++ ")\t " ++ prettyPrintEntry (cp ! i) cp ++ "\n") l
{----------------------------------------
 - Prints a .class file metadata
 - --------------------------------------}
innerAttributeToString flag = case flag of 
	PublicIC		->	"public"
	PrivateIC 	->	"private"
	ProtectedIC ->	"protected"
	FinalIC			->	"final"
	AbstractIC	->	"abstract"
	StaticIC		->	"static"


prettyPrintInnerClasses (attr, i1, i2, i3) cp = do putStrLn $ (unwords $ map innerAttributeToString attr)  ++ 
							    prettyPrintEntry (entryAt i1 cp) cp ++ " = " ++
							    prettyPrintEntry (entryAt i2 cp) cp ++ " of " ++
							    prettyPrintEntry (entryAt i3 cp) cp

prettyPrintAttributes [] 		 cp =    								putStrLn ""
prettyPrintAttributes (DeprecatedCA:t)    cp = do 	
																										putStrLn "Deprecated flag set."
																										prettyPrintAttributes t cp
prettyPrintAttributes (SyntheticCA:t)     cp = do 	
																										putStrLn "Synthetic flag set."
																										prettyPrintAttributes t cp
prettyPrintAttributes (SourceFile f:t) 	 cp = do 		
																										putStrLn $ "SourceFile set: " ++ f
																										prettyPrintAttributes t cp
prettyPrintAttributes (InnerClasses c:t) cp = do 		
																										putStrLn "InnerClasses:"
																										sequence $ map (\ic -> prettyPrintInnerClasses ic cp) c
																										prettyPrintAttributes t cp

classAccessFlagToString flag = case flag of
	PublicC			-> "public"	
	FinalC			-> "final"
	SuperC			-> "super"
	InterfaceC	-> "interface"
	AbstractC		-> "abstract"
	PackageC		-> "package"
	SyntheticC	-> "synthetic"
	AnnotationC	-> "annotation"
	EnumC				-> "enum"


prettyPrintMetadata (JMeta (CN n, CA a {-XXX:Package-}, parent, interfaces, CV (vm, vM), attributes)) cp = do
	putStr   $ n ++ "\n"
	putStrLn $ "Class Attributes: " ++ (concat $ intersperse ", " (map classAccessFlagToString a))
	putStrLn $ "Class Parent: " ++ case parent of
																		Just (CP p) 	-> p ++ "\n"
																		Nothing				-> "No parent.\n"
	putStrLn $ "Version: " ++ show vm ++ " " ++ show vM
	prettyPrintAttributes attributes cp

prettyPrint (JC jm cp body) = do
	putStrLn $ show max ++ " entries in the constant pool."
	putStr $ "Class "
	prettyPrintMetadata jm cp
	prettyPrintConstantPool cp [min..max]
	prettyPrintBody body cp
	where (min, max) = bounds cp

prettyPrint (JI jm cp body) = do
	putStrLn $ "Max constant pool is " ++ show max
	putStr   $ "Interface "
	prettyPrintMetadata jm cp
	prettyPrintConstantPool cp [min..max]
	prettyPrintBody body cp
	where (min, max) = bounds cp

	---
	--
	---
	
prettyPrintEnvironment = mapM (\(a, b) -> do {putStrLn $ "Class " ++ a ++ "'s super chain:\n is"
																							; mapM (\(n,m) -> putStrLn n) b})


